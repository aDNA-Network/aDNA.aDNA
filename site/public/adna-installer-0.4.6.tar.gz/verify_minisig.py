#!/usr/bin/env python3
"""verify_minisig.py -- verify a minisign signature with nothing but the stdlib.

Why this exists (Gangway Phase C1): the payload tarball is signed with minisign
(research_security_2026-08 item 2), and the bootstrap verifies that signature before
executing anything from the tarball. A fresh machine has no minisign binary and the
installer's contract is "python3 and nothing else" -- so verification is pure stdlib:
Ed25519 exactly as specified in RFC 8032, and blake2b from hashlib for minisign's
prehashed mode. One signature over one small file; the ~100 ms a pure-python
scalar-multiply costs is irrelevant here.

    python3 verify_minisig.py --pubkey <56-char base64> <file> <file.minisig>
    python3 verify_minisig.py --self-test

Exit 0 = signature valid. Anything else = refuse; the caller treats it as a hard stop.

Trust chain note, stated honestly: in the curl|sh flow this runs AFTER the sha256 pin
check, from files the pin already authenticated -- there it is defense in depth. Its
independent value is in the channels the pin does not cover: package-manager builds
(PKGBUILD/formula verify the tarball signature at build time) and anyone auditing a
release artifact without the bootstrap. See security_design_notes.md.
"""
from __future__ import annotations
import base64, hashlib, sys

# ---------------------------------------------------------------- Ed25519 (RFC 8032)
# The reference construction, compact form. No third-party crypto: this must run on a
# machine that has python3 and nothing else.
_p = 2**255 - 19
_q = 2**252 + 27742317777372353535851937790883648493
_d = -121665 * pow(121666, _p - 2, _p) % _p


def _sha512(b: bytes) -> bytes:
    return hashlib.sha512(b).digest()


def _pt_add(P, Q):
    x1, y1, z1, t1 = P
    x2, y2, z2, t2 = Q
    a = (y1 - x1) * (y2 - x2) % _p
    b = (y1 + x1) * (y2 + x2) % _p
    c = 2 * t1 * t2 * _d % _p
    dd = 2 * z1 * z2 % _p
    e, f, g, h = b - a, dd - c, dd + c, b + a
    return (e * f % _p, g * h % _p, f * g % _p, e * h % _p)


def _pt_mul(s: int, P):
    Q = (0, 1, 1, 0)  # identity
    while s > 0:
        if s & 1:
            Q = _pt_add(Q, P)
        P = _pt_add(P, P)
        s >>= 1
    return Q


def _pt_equal(P, Q) -> bool:
    # cross-multiply to compare projective points
    return (P[0] * Q[2] - Q[0] * P[2]) % _p == 0 and (P[1] * Q[2] - Q[1] * P[2]) % _p == 0


def _recover_x(y: int, sign: int):
    if y >= _p:
        return None
    x2 = (y * y - 1) * pow(_d * y * y + 1, _p - 2, _p)
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (_p + 3) // 8, _p)
    if (x * x - x2) % _p != 0:
        x = x * pow(2, (_p - 1) // 4, _p) % _p
    if (x * x - x2) % _p != 0:
        return None
    if (x & 1) != sign:
        x = _p - x
    return x


_g_y = 4 * pow(5, _p - 2, _p) % _p
_g_x = _recover_x(_g_y, 0)
_G = (_g_x, _g_y, 1, _g_x * _g_y % _p)


def _decompress(b: bytes):
    if len(b) != 32:
        return None
    y = int.from_bytes(b, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _recover_x(y, sign)
    if x is None:
        return None
    return (x, y, 1, x * y % _p)


def ed25519_verify(pub: bytes, msg: bytes, sig: bytes) -> bool:
    if len(pub) != 32 or len(sig) != 64:
        return False
    A = _decompress(pub)
    R = _decompress(sig[:32])
    if A is None or R is None:
        return False
    s = int.from_bytes(sig[32:], "little")
    if s >= _q:
        return False
    h = int.from_bytes(_sha512(sig[:32] + pub + msg), "little") % _q
    return _pt_equal(_pt_mul(s, _G), _pt_add(R, _pt_mul(h, A)))


# ---------------------------------------------------------------- minisign format
def parse_pubkey(b64: str):
    """base64 -> (key_id 8B, ed25519 pubkey 32B). Format: 'Ed' + key_id + pubkey."""
    try:
        raw = base64.b64decode(b64.strip(), validate=True)
    except Exception:
        return None
    if len(raw) != 42 or raw[:2] != b"Ed":
        return None
    return raw[2:10], raw[10:42]


def parse_sigfile(text: str):
    """.minisig -> (alg 2B, key_id 8B, sig 64B, trusted_comment str, global_sig 64B)."""
    lines = [ln for ln in text.splitlines() if ln.strip()]
    if len(lines) < 4 or not lines[2].startswith("trusted comment: "):
        return None
    try:
        blob = base64.b64decode(lines[1], validate=True)
        gsig = base64.b64decode(lines[3], validate=True)
    except Exception:
        return None
    if len(blob) != 74 or blob[:2] not in (b"Ed", b"ED") or len(gsig) != 64:
        return None
    return blob[:2], blob[2:10], blob[10:74], lines[2][len("trusted comment: "):], gsig


def verify_file(pubkey_b64: str, file_path: str, sig_path: str) -> str | None:
    """None = valid. Otherwise a one-line plain-words reason."""
    pk = parse_pubkey(pubkey_b64)
    if pk is None:
        return "the public key is not a valid minisign key"
    key_id, pub = pk
    try:
        sig_text = open(sig_path, encoding="utf-8").read()
    except OSError:
        return "the signature file could not be read"
    parsed = parse_sigfile(sig_text)
    if parsed is None:
        return "the signature file is not a valid minisign signature"
    alg, sig_key_id, sig, trusted, gsig = parsed
    if sig_key_id != key_id:
        return "the signature was made with a different key than the one pinned here"
    try:
        data = open(file_path, "rb").read()
    except OSError:
        return "the signed file could not be read"
    msg = hashlib.blake2b(data, digest_size=64).digest() if alg == b"ED" else data
    if not ed25519_verify(pub, msg, sig):
        return "the signature does not match the file"
    if not ed25519_verify(pub, sig + trusted.encode(), gsig):
        return "the trusted comment does not match the signature"
    return None


# ---------------------------------------------------------------- self-test
def self_test() -> int:
    """Known-bad first: a check never observed to refuse is not a check."""
    fails = 0

    def case(name, ok):
        nonlocal fails
        print(f"  [{'ok' if ok else 'XX'}] {name}")
        fails += 0 if ok else 1

    # RFC 8032 test vector 1 (empty message)
    pub1 = bytes.fromhex("d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a")
    sig1 = bytes.fromhex("e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e06522490155"
                         "5fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b")
    # known-bad FIRST: flip one bit of the signature
    bad = bytearray(sig1); bad[0] ^= 1
    case("flipped-bit signature REFUSED", not ed25519_verify(pub1, b"", bytes(bad)))
    case("wrong message REFUSED", not ed25519_verify(pub1, b"x", sig1))
    case("RFC 8032 vector 1 verifies", ed25519_verify(pub1, b"", sig1))
    # RFC 8032 test vector 3 (msg af82)
    pub3 = bytes.fromhex("fc51cd8e6218a1a38da47ed00230f0580816ed13ba3303ac5deb911548908025")
    sig3 = bytes.fromhex("6291d657deec24024827e69c3abe01a30ce548a284743a445e3680d7db5ac3ac"
                         "18ff9b538d16f290ae67f760984dc6594a7c15e9716ed28dc027beceea1ec40a")
    case("RFC 8032 vector 3 verifies", ed25519_verify(pub3, bytes.fromhex("af82"), sig3))
    # format parsers: a truncated pubkey and a malformed sigfile must both refuse
    case("truncated pubkey REFUSED", parse_pubkey(base64.b64encode(b"Ed" + b"\0" * 30).decode()) is None)
    case("malformed sigfile REFUSED", parse_sigfile("not\na\nreal\nsigfile") is None)
    print(f"\nself-test: {6 - fails}/6")
    return 1 if fails else 0


def main() -> int:
    argv = sys.argv[1:]
    if "--self-test" in argv:
        return self_test()
    if len(argv) != 4 or argv[0] != "--pubkey":
        print("usage: verify_minisig.py --pubkey <base64> <file> <file.minisig>", file=sys.stderr)
        return 2
    reason = verify_file(argv[1], argv[2], argv[3])
    if reason:
        print(f"signature check failed: {reason}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
