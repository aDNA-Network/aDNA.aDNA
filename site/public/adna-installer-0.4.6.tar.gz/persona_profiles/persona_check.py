#!/usr/bin/env python3
"""persona_check.py — validate persona profiles, and enforce the rules a schema cannot.

Pure stdlib (no jsonschema dependency — same constraint node_doctor.py is written to).

A JSON Schema can check shape. It cannot check the four rules this network learned the hard way,
so those are coded here as CROSS-FIELD gates:

  G1  A profile with a non-empty `requires_ratification` MUST NOT be shippable, whatever its status.
  G2  Any graph with generative:true REQUIRES consent.content_policy_required:true — and since no
      content policy exists today, that combination is not shippable either.
  G3  mesh_join:false MUST mean data_transmitted is empty. If we claim local-only, it has to be true.
      (And the converse: mesh_join:true with an empty inventory is an undisclosed collection.)
  G4  terminal_required:true is incompatible with the click-install path; a persona intended for
      non-developers must not quietly require a terminal. Likewise inbound_required:true implies a
      router change, so it cannot be a click-install either.
  G5  cert_request.duration_hours must be present and non-zero — an omitted duration inherits the CA
      wall.
  G6  Every shipped graph needs a license. Bundling is distribution.

Usage:
    python3 persona_check.py                 # validate every persona_*.json beside this file
    python3 persona_check.py --shippable     # exit 1 unless ALL profiles are shippable
    python3 persona_check.py --self-test     # prove each gate CAN fail (negative controls)
"""
from __future__ import annotations
import json, sys, pathlib, copy

HERE = pathlib.Path(__file__).resolve().parent
REQUIRED_TOP = {"persona", "schema_version", "surface", "network", "graphs", "cert_request", "consent"}
PERSONAS = {"developer", "resource_provider", "creative", "founder", "academic", "student"}


def gates(p: dict) -> list[str]:
    """Return a list of blocking reasons. Empty list == shippable."""
    out: list[str] = []
    name = p.get("persona", "<unnamed>")

    missing = REQUIRED_TOP - set(p)
    if missing:
        out.append(f"{name}: missing required key(s): {sorted(missing)}")
        return out                                   # further gates would be noise
    if p["persona"] not in PERSONAS:
        out.append(f"{name}: unknown persona (a seventh is a ratification, not a config edit)")

    # G1 — unratified means unshippable, regardless of the status field
    rr = p.get("requires_ratification") or []
    if rr:
        out.append(f"{name}: G1 {len(rr)} unratified decision(s) — not shippable: {rr[0][:60]}…")

    # G2 — generative content needs a policy that does not exist yet
    gen = [g["name"] for g in p["graphs"] if g.get("generative")]
    if gen and not p["consent"].get("content_policy_required"):
        out.append(f"{name}: G2 generative graph(s) {gen} without content_policy_required")
    if gen:
        out.append(f"{name}: G2 generative graph(s) {gen} — no content policy exists; cannot ship")

    # G3 — the local-only claim must be true, and collection must be disclosed
    mesh = p["network"]["mesh_join"]
    inv = p["consent"].get("data_transmitted") or []
    if not mesh and inv:
        out.append(f"{name}: G3 mesh_join:false but data_transmitted lists {len(inv)} item(s) — the local-only claim is false")
    if mesh and not inv:
        out.append(f"{name}: G3 mesh_join:true with an EMPTY data inventory — undisclosed collection")

    # G4 — click-install compatibility must not be quietly contradicted
    if not p["surface"]["terminal_required"] and p["network"].get("inbound_required"):
        out.append(f"{name}: G4 non-terminal persona requires inbound — a router change needs a human with access")
    if p["persona"] != "developer" and not p["surface"].get("agent_optional", False):
        out.append(f"{name}: G4 non-developer persona with agent_optional:false — that is the Claude-Code dependency, unexited")

    # G5 — never inherit the CA wall
    if not p["cert_request"].get("duration_hours"):
        out.append(f"{name}: G5 cert_request.duration_hours missing/zero — would inherit the CA wall")

    # G6 — distribution needs a licence
    for g in p["graphs"]:
        if not g.get("license"):
            out.append(f"{name}: G6 graph '{g['name']}' has no license — bundling is distribution")
    return out


def load_all() -> list[tuple[str, dict]]:
    return [(f.name, json.loads(f.read_text()))
            for f in sorted(HERE.glob("persona_*.json"))
            if f.name != "persona_schema.json"]


def self_test() -> int:
    """Each gate must be PROVEN to fire. A control never observed to refuse is not a control."""
    base = {
        "schema_version": "adna.network.persona/v1", "persona": "developer",
        "requires_ratification": [],
        "surface": {"primary": "cli", "terminal_required": True, "agent_optional": True},
        "network": {"mesh_join": True, "role": "dial_out_client", "inbound_required": False},
        "graphs": [{"name": "g", "class": "public", "license": "MIT"}],
        "cert_request": {"groups": [], "duration_hours": 8760},
        "consent": {"age_gate_required": True, "supervised_install": False,
                    "content_policy_required": False, "data_transmitted": ["public IP"]},
    }
    assert not gates(base), f"baseline must pass, got {gates(base)}"

    cases = {
        "G1": lambda p: p.update({"requires_ratification": ["undecided thing"]}),
        "G2": lambda p: p["graphs"].append({"name": "gen", "class": "public", "license": "X", "generative": True}),
        "G3": lambda p: p["network"].update({"mesh_join": False}),
        "G4": lambda p: (p.update({"persona": "student"}), p["surface"].update({"agent_optional": False})),
        "G5": lambda p: p["cert_request"].update({"duration_hours": 0}),
        "G6": lambda p: p["graphs"].append({"name": "nolicense", "class": "bundled"}),
    }
    failures = 0
    for gid, mutate in cases.items():
        probe = copy.deepcopy(base)
        mutate(probe)
        found = [g for g in gates(probe) if gid in g]
        if found:
            print(f"  ✓ {gid} fires: {found[0][:88]}")
        else:
            print(f"  ✗ {gid} DID NOT FIRE — the gate is decorative"); failures += 1
    print(f"\nself-test: {len(cases)-failures}/{len(cases)} gates proven to fail")
    return 1 if failures else 0


def main() -> int:
    if "--self-test" in sys.argv:
        return self_test()

    profiles = load_all()
    if not profiles:
        print("no persona_*.json found"); return 1

    blocked = 0
    for fname, p in profiles:
        reasons = gates(p)
        if reasons:
            blocked += 1
            print(f"⛔ {fname}: NOT SHIPPABLE")
            for r in reasons:
                print(f"     {r}")
        else:
            print(f"✅ {fname}: shippable")

    print(f"\n{len(profiles)-blocked}/{len(profiles)} shippable")
    if "--shippable" in sys.argv and blocked:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
