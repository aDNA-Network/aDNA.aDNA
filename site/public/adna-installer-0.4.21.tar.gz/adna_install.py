#!/usr/bin/env python3
"""adna_install.py — the doing half of node onboarding. No agent required.

Companion to `what/network/health/node_doctor/node_doctor.py`, which is the *measuring* half and
already ships agent-free. This adds: detect → refuse-or-plan → install → keygen → config → emit an
enrollment request. It deliberately STOPS before enrollment completes (see §Enrollment).

Design constraints, each earned:

* **Pure stdlib.** Same constraint node_doctor is written to. A partner should not need pip.
* **Dry-run by default.** `--execute` is required to change anything. A tool that mutates a partner's
  machine on first invocation is not a tool a partner should trust.
* **Refuse clearly, never improvise.** Every known trap below cost a real onboarding.
* **The private key is born here and never leaves.** Nothing in this file prints, copies or transmits
  a `.key`. `--self-audit` proves it.
* **No dependency on the signer existing.** Ruling C (2026-08-16) chose scoped auto-signing, but the
  capability is not granted yet, so this emits a request and stops. Human-in-loop today, signer-ready
  later, one interface either way.

Traps encoded (platform, source):
  armv7l / 32-bit ARM   → refuse           (a 64-bit OS is required; 32-bit Pi images cannot join)
  distro nebula 1.9.x   → refuse           (v1-only certs cannot join a v2 mesh; distro packages ship 1.9.x)
  NTP not synced        → refuse           (handshakes silently fail)
  no systemd            → warn + alt path  (WSL2 distros vary)
  WSL2 shared netns     → forbid net.*     (all distros share one netns; a sysctl would hit the host)
  Raspberry Pi OS       → measure sshd     (a key-only claim must be measured, never assumed)
  CGNAT + inbound role  → refuse           (a port-forward cannot work behind carrier-grade NAT)

Usage:
    python3 adna_install.py --profile developer                 # dry-run plan
    python3 adna_install.py --profile developer --execute       # actually do it
    python3 adna_install.py --self-test                         # prove the refusals fire
    python3 adna_install.py --self-audit                        # prove no private key was read
"""
from __future__ import annotations
import argparse, hashlib, json, os, platform, re, shutil, socket, subprocess, sys, tarfile, tempfile, time, pathlib
import urllib.request, urllib.error

VERSION = "0.4.21"          # S345: LICENSE (MIT (c) Lat Labs) ships in the payload. 0.4.0-0.4.2 never published — see release_pins.txt
HERE = pathlib.Path(__file__).resolve().parent

# ── plain output mode + transcript log ───────────────────────────────────────────────────
# Screen readers announce "✓" as "check mark" or skip it; TERM=dumb and non-UTF8 terminals
# mangle it. Rule (research_accessibility_2026-08 §3): symbol + word, ASCII fallback. Plain
# is on for --plain, NO_COLOR (no-color.org), TERM=dumb, or when stdout is not a terminal.
# One translation layer at the stream, so 100+ print sites stay untouched. The same layer
# tees everything to a persistent log file (research §2): when a run fails, the evidence is
# on disk for the helper, not lost with a closed window. Log writes must never break a run.
_PLAIN_MAP = {"✓": "[OK]", "✗": "[FAIL]", "⛔": "[ERROR]", "⚠": "[WARNING]",
              "•": "*", "→": "->", "·": "|", "—": "--", "─": "-", "§": "S", "▶": ">"}
LOG_FILE = pathlib.Path.home() / "adna-install-log.txt"

# ── user-facing strings (per-script catalog — the conformance reading-age gate reads
#    everything quoted between these two sentinels; keep sentences short, one idea each) ──
# strings-begin
MSG_RERUN = "It is safe to run the same command again."
MSG_HELPER = "Error code {code}. Full log: {log}"
# strings-end

_FAIL_CODE = "GEN-01"        # the failure epilogue reads this; refine it at the big exits
_EPILOGUE = True             # self-test/self-audit are developer modes — no epilogue there


def _set_code(code: str) -> None:
    global _FAIL_CODE
    _FAIL_CODE = code


def _plain_wanted(flag: bool = False) -> bool:
    return (flag or bool(os.environ.get("NO_COLOR")) or os.environ.get("TERM") == "dumb"
            or not sys.stdout.isatty())


def _install_output(plain: bool, log: pathlib.Path | None) -> None:
    table = str.maketrans(_PLAIN_MAP)
    sink = None
    if log:
        try:
            sink = open(log, "a", encoding="utf-8")
            sink.write(f"\n--- adna_install {VERSION} · {time.strftime('%Y-%m-%d %H:%M:%S')} · "
                       f"{sys.platform}/{platform.machine()} · argv={sys.argv[1:]}\n")
        except OSError:
            sink = None      # an unwritable log never blocks an install

    class _T:
        def __init__(self, s): self._s = s

        def write(self, t):
            if sink:
                try:
                    sink.write(t); sink.flush()
                except OSError:
                    pass
            return self._s.write(t.translate(table) if plain else t)

        def __getattr__(self, n): return getattr(self._s, n)

    sys.stdout, sys.stderr = _T(sys.stdout), _T(sys.stderr)


_NOTES: list[str] = []      # noteworthy-but-not-fatal items; printed once at the end, only if any


def _note(msg: str) -> None:
    _NOTES.append(msg)


def _fail_epilogue() -> None:
    """Layers 2-4 of the failure block (research §2). Layer 1 — what happened, in plain
    words — is the message each failing site already printed directly above this."""
    print(f"\n{MSG_RERUN}")
    print(f"{MSG_HELPER.format(code=_FAIL_CODE, log=LOG_FILE)}")

# Persona lookup must work for BOTH shapes this file ships in: inside the vault tree, and as a FLAT
# COPY beside its personas (which is how a partner receives it, and how a curl-installer will lay it
# down). Resolving only vault-relative broke on the Pi at first real test — and the self-test did not
# catch it, because self-test uses inline dicts and never loads a persona file. Ordered candidates:
def _persona_dirs() -> list[pathlib.Path]:
    env = os.environ.get("ADNA_PERSONA_DIR")
    return [d for d in [
        pathlib.Path(env).expanduser() if env else None,   # explicit override wins
        HERE / "persona_profiles",                          # flat copy — the partner shape
        HERE,                                               # personas dropped beside the script
        # in-vault; guarded — a payload two levels from / has no parents[1] and crashed here
        HERE.parents[1] / "profiles" / "persona_profiles" if len(HERE.parents) > 1 else None,
    ] if d]

_KEY_SUFFIXES = (".key", ".pem", "id_ed25519", "id_rsa")
_READS: list[str] = []          # every path this run opened — for --self-audit


def _read(path: pathlib.Path) -> str | None:
    _READS.append(str(path))
    try:
        return path.read_text(errors="ignore")
    except Exception:
        return None


def _run(cmd: list[str], timeout: int = 20) -> tuple[int, str]:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout + p.stderr).strip()
    except FileNotFoundError:
        return 127, "not found"
    except subprocess.TimeoutExpired:
        return 124, "timeout"


def _nebula_bins(bindir):
    """THE nebula/nebula-cert resolver — ONE precedence order for every site: our own bindir
    install first (those bytes were checksum-verified at acquire time), PATH second. Before
    this existed, detect/keygen/config-check/service each picked their own binary (S349
    review: the version gate could pass on a binary the service never runs)."""
    found = []
    for name in ("nebula", "nebula-cert"):
        own = bindir / name if bindir else None
        if own and own.is_file() and os.access(own, os.X_OK):
            found.append(str(own))
        else:
            found.append(shutil.which(name))
    return found[0], found[1]


def _persist_payload(prefix: pathlib.Path) -> None:
    """Copy the running payload to <prefix>/installer/ so printed resume commands survive the
    mktemp dir a curl-piped run executes from (F-III-4, ruled 2026-08-25 — the old commands
    only worked because install.sh's exec accidentally defeated its own cleanup trap, and died
    on reboot). Best-effort: failure costs resume-after-reboot, never the install."""
    dst = prefix / "installer"
    if HERE == dst.resolve():
        return                       # already running from the durable copy
    try:
        dst.mkdir(parents=True, exist_ok=True)
        for name in ("adna_install.py", "network_constants.json", "verify_minisig.py"):
            src = HERE / name
            if src.is_file():
                shutil.copy2(src, dst / name)
        pp = HERE / "persona_profiles"
        if pp.is_dir():
            shutil.copytree(pp, dst / "persona_profiles", dirs_exist_ok=True)
    except OSError:
        pass


def _self_for_resume(root: pathlib.Path) -> pathlib.Path:
    """The path a PRINTED resume command should reference: the durable payload copy when it
    exists, else this file. Never print a path into a temp dir if a durable one is there."""
    durable = root.parent / "installer" / "adna_install.py"
    return durable if durable.is_file() else pathlib.Path(__file__).resolve()


# ── detect ───────────────────────────────────────────────────────────────────────────────────
def detect(bindir: pathlib.Path | None = None) -> dict:
    d: dict = {
        "os": sys.platform, "machine": platform.machine(),
        "hostname": socket.gethostname().split(".")[0],
        "is_wsl": False, "is_rpi": False, "os_class": None,
        "systemd": False, "ntp_synced": None, "nebula": None,
        "brew_prefix": None, "public_ip": None, "cgnat": None,
        "overlay_ip": None,
    }
    # Already-on-the-network detection: an interface holding an address inside our overlay CIDR
    # is the strongest possible signal that this machine is ALREADY enrolled. Without this, the
    # operator's own live node emitted a fresh enrollment request — a second identity for a
    # machine that has one, presented as the normal next step.
    prefix = C["overlay"]["cidr"].rsplit(".", 1)[0] + "."
    if sys.platform == "darwin":
        rc, out = _run(["ifconfig"])
    else:
        rc, out = _run(["ip", "-4", "-o", "addr"])
    if rc == 0:
        m = re.search(r"inet (" + re.escape(prefix) + r"\d+)", out)
        if m:
            d["overlay_ip"] = m.group(1)
    rel = (_read(pathlib.Path("/proc/version")) or "").lower()
    d["is_wsl"] = "microsoft" in rel
    model = _read(pathlib.Path("/proc/device-tree/model")) or ""
    osrel = _read(pathlib.Path("/etc/os-release")) or ""
    d["is_rpi"] = "raspberry pi" in (model + osrel).lower()

    if sys.platform == "darwin":
        d["os_class"] = "macos"
        rc, out = _run(["brew", "--prefix"])
        d["brew_prefix"] = out if rc == 0 else None
    elif sys.platform.startswith("linux"):
        d["os_class"] = "wsl2" if d["is_wsl"] else "linux"
    elif sys.platform.startswith("win"):
        d["os_class"] = "windows"

    d["systemd"] = pathlib.Path("/run/systemd/system").exists()

    rc, out = _run(["timedatectl", "show", "-p", "NTPSynchronized", "--value"])
    if rc == 0:
        d["ntp_synced"] = out.strip() == "yes"

    # Resolve via _nebula_bins (bindir first): a previous run installs to ~/.adna/bin, which
    # is not on PATH — a PATH-only look reported nebula=absent about its own install (S349).
    nebula_bin, _ = _nebula_bins(bindir)
    d["nebula_self"] = bool(bindir) and nebula_bin == str(bindir / "nebula") if nebula_bin else False
    if nebula_bin:
        rc, out = _run([nebula_bin, "-version"])
        m = re.search(r"(\d+)\.(\d+)\.(\d+)", out)
        if m:
            d["nebula"] = tuple(int(x) for x in m.groups())
    return d


def public_ip(d: dict) -> None:
    rc, out = _run(["curl", "-fsS", "--max-time", "6", "https://api.ipify.org"])
    if rc == 0 and re.fullmatch(r"[\d.]+", out.strip()):
        ip = out.strip()
        d["public_ip"] = ip
        first, second = (int(x) for x in ip.split(".")[:2])
        d["cgnat"] = first == 100 and 64 <= second <= 127


# ── refuse or plan ───────────────────────────────────────────────────────────────────────────
def preflight(d: dict, persona: dict) -> tuple[list[str], list[str]]:
    """Returns (blockers, warnings). A blocker means STOP — do not improvise around it."""
    blockers: list[str] = []
    warns: list[str] = []
    inbound = persona["network"].get("inbound_required", False)

    if d["machine"] in ("armv7l", "armv6l", "i386", "i686"):
        blockers.append(
            f"32-bit OS ({d['machine']}) — a 64-bit OS is required. On a Raspberry Pi: re-image "
            "with 64-bit Raspberry Pi OS.")

    if d["nebula"] and d["nebula"] < NEBULA_MIN:
        v = ".".join(map(str, d["nebula"]))
        if d.get("nebula_self"):
            # OUR install is below the floor (min_version raised since). Blocking here would
            # make the rerun promise false forever — the remedy IS the rerun (the acquire
            # gate re-fetches the pinned release in place). S349 review finding.
            warns.append(f"self-installed nebula {v} is below the required "
                         f"{'.'.join(map(str, NEBULA_MIN))} — this run upgrades it in place.")
        else:
            blockers.append(
                f"nebula {v} is too old (need >= {'.'.join(map(str, NEBULA_MIN))}). Remove the distro "
                "package (e.g. sudo apt remove nebula) — this installer then fetches the right version.")

    if d["ntp_synced"] is False:
        blockers.append(
            "system clock is not synced. Fix:  sudo timedatectl set-ntp true   — then rerun.")

    if inbound and d["cgnat"]:
        blockers.append(
            f"this network is behind CGNAT (public IP {d['public_ip']}) and this persona needs an "
            "inbound port, which CGNAT cannot forward. Use a client persona instead.")

    if d["os_class"] in ("linux", "wsl2") and not d["systemd"]:
        warns.append("systemd not detected — the service step will need the init-script variant.")

    if d["is_wsl"]:
        warns.append("WSL2: distros share one network namespace — no net.* sysctl will be written.")

    if d["is_rpi"]:
        rc, out = _run(["sshd", "-T"])
        pw = "passwordauthentication yes" in out.lower()
        if pw:
            warns.append("sshd password auth is ON. Nothing here opens inbound SSH, but turn it off "
                         "if you ever do:  see raspi-config > SSH.")

    if persona.get("requires_ratification"):
        blockers.append(
            f"persona '{persona['persona']}' is not approved for install yet "
            f"({len(persona['requires_ratification'])} pending decision(s)).")
    return blockers, warns


# ── plan ─────────────────────────────────────────────────────────────────────────────────────
def nebula_source(d: dict, bindir: pathlib.Path | None = None) -> str:
    # Display-only, but it must tell the truth: acquire_nebula() ALWAYS fetches the pinned
    # upstream release — it never uses brew or a distro package (their nebula can lag behind
    # the v2-mesh floor). This string used to say "brew install nebula" on macOS, which the
    # execute path never did (F-S393-01 family; caught S346 on the first real macOS run).
    dest = str(bindir) if bindir else "/usr/local/bin"
    if d["os_class"] == "macos":
        return f"github release nebula-darwin.zip → {dest}  (NOT brew — pinned release)"
    arch = {"aarch64": "arm64", "arm64": "arm64", "x86_64": "amd64"}.get(d["machine"], d["machine"])
    return f"github release nebula-linux-{arch}.tar.gz → {dest}  (NOT the distro package)"


def pki_dir(d: dict, instance: str = "nebula-1043", prefix: str | None = None) -> str:
    # Must agree with _instance_root(). A plan that prints one path and writes another is the
    # "confident, specific, wrong" class — caught on the first real --execute run (2026-08-16).
    return str(_instance_root(d, instance, prefix) / "pki")


def plan(d: dict, persona: dict, instance: str = "nebula-1043", prefix: str | None = None,
         bindir: pathlib.Path | None = None) -> list[str]:
    net = persona["network"]
    steps = [
        f"install nebula        : {nebula_source(d, bindir)}",
        f"keypair (born here)   : {pki_dir(d, instance, prefix)}/host.key  (0600, never leaves this machine)",
        f"config                : role={net['role']}  mesh_join={net['mesh_join']}  "
        f"listen_port={'fixed' if net.get('inbound_required') else '0 (dial-out)'}",
        f"cert request          : groups={persona['cert_request']['groups'] or '[] (minimal privilege)'}  "
        f"duration={persona['cert_request']['duration_hours']}h",
        f"graphs to fetch       : {len(persona['graphs'])} "
        f"({sum(1 for g in persona['graphs'] if g['class']=='private')} deferred until forge sign-in)",
        f"aDNA workspace        : clone to {C['workspace']['clone_target']} (optional; --no-workspace to skip)",
        "enrollment            : emit request, then STOP (see below)",
    ]
    if d.get("overlay_ip"):
        steps.insert(0, f"*** an overlay address ({d['overlay_ip']}) is already present — no enrollment request will be produced (--second-identity to override) ***")
    if not net["mesh_join"]:
        steps.insert(0, "*** LOCAL-ONLY PROFILE — this node will not join the mesh and transmits nothing ***")
    return steps


def enrollment_request(d: dict, persona: dict, host_pub: str | None) -> dict:
    return {
        "schema": REQUEST_SCHEMA,
        "installer_version": VERSION,
        "persona": persona["persona"],
        "node": {
            "hostname": d["hostname"], "os_class": d["os_class"], "machine": d["machine"],
            "is_wsl": d["is_wsl"], "is_rpi": d["is_rpi"],
            "nebula": ".".join(map(str, d["nebula"])) if d["nebula"] else None,
            "public_ip": d["public_ip"], "cgnat": d["cgnat"],
        },
        "cert_request": {
            **persona["cert_request"],
            # Gangway A3: the invite's envelope is checked against role/inbound too, so the
            # request states them explicitly instead of leaving the far end to infer them
            # from the persona name. Still claims, not authorizations (F-S346-04) — the
            # master recomputes everything from the persona at signing time.
            "role": persona["network"]["role"],
            "inbound_required": persona["network"].get("inbound_required", False),
            # Ruling C (2026-08-16): auto-signable ONLY when it has earned it. ADR-022
            # (2026-08-26): the t0_newcomer floor is exempt from the privilege test — it
            # confers no reach that groups:[] did not; only groups BEYOND the floor count.
            "auto_signable": (
                not [g for g in persona["cert_request"]["groups"] if g != "t0_newcomer"]
                and not persona["network"].get("inbound_required", False)
                and persona["network"]["role"] in ("dial_out_client", "relay_client", "none")
            ),
        },
        "host_pub": host_pub,
        "note": "PUBLIC key only. No private key material appears in this document, by construction.",
    }




def _reach_overlay() -> tuple[str | None, int]:
    """Try EVERY lighthouse, first answer wins. Only all-fail means unreachable — a single
    target can be down while the network is fine (operator finding, 2026-08-23)."""
    lhs = C["lighthouses"]
    for lh in lhs:
        rc, _ = _run(["ping", "-c", "1", "-W", "2", lh], timeout=10)
        if rc == 0:
            return lh, len(lhs)
    # second, patient pass — one slow lighthouse must not read as an outage
    for lh in lhs:
        rc, _ = _run(["ping", "-c", "2", "-W", "4", lh], timeout=20)
        if rc == 0:
            return lh, len(lhs)
    return None, len(lhs)


def _install_git() -> None:
    """Try the system package manager for git. Best-effort and non-fatal: sudo prompts on the
    terminal when there is one (it reads /dev/tty, so this works even under curl-piped stdin);
    with no terminal or a refusal, the caller falls back to printing the manual command."""
    managers = [
        (["pacman", "-S", "--noconfirm", "--needed", "git"], True),
        (["apt-get", "install", "-y", "git"], True),
        (["dnf", "install", "-y", "git"], True),
        (["zypper", "--non-interactive", "install", "git"], True),
        (["apk", "add", "git"], True),
        (["brew", "install", "git"], False),
    ]
    for cmd, needs_root in managers:
        if not shutil.which(cmd[0]):
            continue
        if needs_root and os.geteuid() != 0:
            if not os.path.exists("/dev/tty"):
                return          # nowhere to ask for a password — leave it to the manual hint
            cmd = ["sudo"] + cmd
        print(f"• installing git:  {' '.join(cmd)}")
        rc, out = _run(cmd, timeout=600)
        if rc == 0:
            print("✓ git installed")
        else:
            print(f"⚠ git install failed ({(out.splitlines() or ['?'])[-1][:80]})")
        return


def setup_workspace(skip: bool) -> str | None:
    """Clone the aDNA workspace. Optional, non-fatal, and never requires Claude Code.

    Unifying the two installs (operator ruling, 2026-08-16) means one command both joins the
    network and gives you the workspace. They stay INDEPENDENT goods: the mesh works with no
    workspace, the workspace works with no mesh, and neither needs an AI assistant. The site
    previously advertised `git clone ... && cd ~/aDNA && claude` as canonical, which made Claude
    Code a hard dependency of getting started; that trailing `claude` is exactly what this
    replaces.

    Never clobbers an existing directory, and a failure here does NOT fail the install -- the
    network half is the part with a human waiting on the other end.
    """
    w = C["workspace"]
    target = pathlib.Path(w["clone_target"].replace("~", str(pathlib.Path.home())))
    if skip:
        _note(f"workspace skipped (--no-workspace). Get it later:  git clone {w['canonical_repo_git']} {w['clone_target']}")
        return None
    if target.exists():
        pass
        return str(target)
    if not shutil.which("git"):
        _install_git()
    if not shutil.which("git"):
        _note(f"workspace skipped — git could not be installed. Install git, then:  git clone {w['canonical_repo_git']} {w['clone_target']}")
        return None

    print(f"• cloning workspace to {target}")
    rc, out = _run(["git", "clone", "--depth", "1", w["canonical_repo_git"], str(target)], timeout=300)
    if rc != 0:
        # Non-fatal by design. Someone is waiting to approve the enrollment request; do not
        # throw that away because a git clone failed.
        print(f"⚠ workspace clone FAILED (the network install is unaffected): {out.splitlines()[-1] if out else rc}")
        print(f"Retry later:  git clone {w['canonical_repo_git']} {w['clone_target']}")
        return None
    print(f"✓ workspace cloned to {target}")
    return str(target)


# ── activate ─────────────────────────────────────────────────────────────────────────────────
# The SECOND command. First run produces an enrollment request and stops; a human signs it and
# sends back ca.crt + host.crt; this turns those into a running node.
#
# Split deliberately, for two reasons. There is no certificate at first-install time, so a service
# started then would only crash-loop. And this is the ONLY step that needs root — keeping it apart
# is what lets the first command stay honestly no-privilege.

def _cert_json(nebula_cert: str, path: pathlib.Path) -> dict | None:
    rc, out = _run([nebula_cert, "print", "-json", "-path", str(path)])
    if rc != 0:
        return None
    try:
        d = json.loads(out)
        return d[0] if isinstance(d, list) else d
    except (json.JSONDecodeError, IndexError):
        return None


def _pub_hex(path: pathlib.Path) -> str | None:
    """Public key from a nebula .pub file, as hex — the form the cert reports it in."""
    import base64
    txt = _read(path)
    if not txt:
        return None
    body = "".join(l for l in txt.splitlines() if "-----" not in l).strip()
    try:
        return base64.b64decode(body).hex()
    except Exception:
        return None


def cert_gates(root: pathlib.Path, nebula_cert: str) -> list[str]:
    """Everything that must be true before a service is worth starting. Blockers, in order."""
    bad: list[str] = []
    ca, crt, pub = root / "pki/ca.crt", root / "pki/host.crt", root / "pki/host.pub"

    missing = [str(f) for f in (ca, crt) if not f.is_file()]
    if missing:
        bad.append("the signed certificate has not arrived yet. Save the two files you were sent as:\n"
                   f"       {ca}\n  {crt}\n"
                   "     then run this again. (Nothing else is needed — your private key is already here.)")
        return bad

    # A1 — signed by a CA we trust. Catches a cert minted by the wrong authority entirely.
    rc, out = _run([nebula_cert, "verify", "-ca", str(ca), "-crt", str(crt)])
    if rc != 0:
        bad.append(f"certificate does not verify against {ca}:\n  {out.splitlines()[0] if out else rc}")

    info = _cert_json(nebula_cert, crt)
    if not info:
        bad.append(f"could not read {crt} — it may be truncated or not a nebula certificate")
        return bad

    # A2 — THE KEY-BINDING GATE. A certificate that verifies against the CA can still
    # have been issued for somebody else's public key: it would be perfectly valid and useless,
    # and nebula's failure mode is a silent non-handshake that looks like a network problem.
    # Compare what the CA signed against the key that was actually born on this machine.
    cert_pub, have_pub = info.get("publicKey"), _pub_hex(pub)
    if not have_pub:
        bad.append(f"cannot read {pub} — needed to prove the certificate was issued for THIS machine's key")
    elif cert_pub != have_pub:
        bad.append("CERTIFICATE / KEY MISMATCH — this certificate was issued for a different key.\n"
                   f"       certificate carries : {cert_pub}\n"
                   f"       this machine's key  : {have_pub}\n"
                   "     It would verify against the CA and still never connect. Ask for a certificate\n"
                   "     issued against the enrollment request from THIS machine.")

    det = info.get("details", {})
    # A3 — validity window. An expired cert fails as a silent non-handshake too.
    na = det.get("notAfter", "")
    if na:
        try:
            import datetime as _dt
            # Go emits RFC3339 with a literal Z; fromisoformat only accepts that on 3.11+.
            # On Ubuntu 22.04 / Debian 11 (3.10) the Z raised ValueError, the except swallowed
            # it, and the EXPIRY GATE NEVER FIRED — decorative, found by code review.
            exp = _dt.datetime.fromisoformat(na.replace("Z", "+00:00"))
            now = _dt.datetime.now(exp.tzinfo)
            if exp <= now:
                bad.append(f"certificate EXPIRED on {na}. Request a new one.")
            elif (exp - now).days < 30:
                print(f"⚠ certificate expires in {(exp - now).days} day(s) ({na}) — plan a renewal")
        except ValueError:
            pass

    # A4 — the address is inside our overlay. A cert for the wrong network joins nothing.
    nets = det.get("networks") or []
    want = C["overlay"]["cidr"].rsplit(".", 2)[0]
    if nets and not any(n.startswith(want) for n in nets):
        bad.append(f"certificate address {nets} is outside this overlay ({C['overlay']['cidr']})")
    return bad


def render_service(d: dict, root: pathlib.Path, nebula_bin: str, instance: str) -> tuple[str, str, str]:
    """Return (kind, install_path, contents) for this platform's service manager."""
    if d["os_class"] == "macos":
        label = f"network.adna.{instance}"
        return ("launchd", f"/Library/LaunchDaemons/{label}.plist", f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>{label}</string>
  <key>ProgramArguments</key>
  <array>
    <string>{nebula_bin}</string>
    <string>-config</string>
    <string>{root}/config.yml</string>
  </array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>/var/log/{instance}.log</string>
  <key>StandardErrorPath</key><string>/var/log/{instance}.err.log</string>
</dict>
</plist>
""")
    # systemd. Type=simple rather than notify: notify needs nebula built with sd-notify support
    # and fails closed as a startup timeout if it is not there. simple always works.
    return ("systemd", f"/etc/systemd/system/{instance}.service", f"""[Unit]
Description=Nebula overlay ({instance}) — aDNA lattice
Documentation=https://adna.network/install
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart={nebula_bin} -config {root}/config.yml
Restart=always
RestartSec=5
SyslogIdentifier={instance}
# Modest hardening. NOT ProtectSystem=strict or PrivateTmp: nebula needs to create a tun device
# and read its pki, and a broken sandbox here presents as a mesh outage that is painful to trace.
NoNewPrivileges=yes
ProtectHome=read-only

[Install]
WantedBy=multi-user.target
""")


def activate(d: dict, root: pathlib.Path, instance: str, bindir: pathlib.Path, dry: bool) -> int:
    _set_code("ACT-01")
    print(f"\nACTIVATING {root}\n")
    _n, _nc = _nebula_bins(bindir)
    nebula      = _n  or str(bindir / "nebula")
    nebula_cert = _nc or str(bindir / "nebula-cert")
    if not pathlib.Path(nebula).exists():
        print(f"⛔ nebula binary not found at {nebula}. Run the installer first.")
        return 1

    blockers = cert_gates(root, nebula_cert)
    if blockers:
        for b in blockers:
            print(f"⛔ {b}")
        return 1

    rc, out = _run([nebula, "-test", "-config", str(root / "config.yml")])
    if rc != 0:
        print(f"⛔ config does not load: {out.splitlines()[-1] if out else rc}")
        return 1

    kind, path, body = render_service(d, root, nebula, instance)
    if kind == "systemd" and not d["systemd"]:
        print("\n• no systemd on this machine, so there is no service to install.")
        print(f"Run it yourself (as root, it needs to create a tun device):\n"
              f"       sudo {nebula} -config {root}/config.yml")
        return 0

    if dry:
        print(f"\n(dry run) would write {kind} unit to {path}:\n")
        print("\n".join("       " + l for l in body.splitlines()))
        return 0

    # THE ONLY STEP THAT NEEDS ROOT. Nebula must create a tun device. Rather than invoke sudo
    # ourselves — which would mean prompting for a password from a script the user piped from the
    # internet — print the exact command and let them run it knowingly.
    if os.geteuid() != 0:
        print(f"\nReady. The last step needs root (nebula creates a network device). Run:\n")
        print(f"sudo {sys.executable} {_self_for_resume(root)} --activate \\")
        print(f"  --prefix {root.parent} --instance {instance} --bindir {bindir} --execute\n")
        return 0

    pathlib.Path(path).write_text(body)
    print(f"✓ {kind} unit written to {path}")
    if kind == "systemd":
        _run(["systemctl", "daemon-reload"])
        rc, out = _run(["systemctl", "enable", "--now", f"{instance}.service"], timeout=60)
    else:
        rc, out = _run(["launchctl", "load", "-w", path], timeout=60)
    if rc != 0:
        print(f"⛔ could not start the service: {out}")
        return 1
    print(f"✓ service enabled and started")

    # Prove it, do not assume it. A started service that never handshakes is the common failure.
    lighthouse, n_lh = _reach_overlay()
    if lighthouse:
        print(f"\n✓ On the network (lighthouse {lighthouse} answered)")
    else:
        print(f"⚠ service is running but none of {n_lh} lighthouses answered yet.")
        print(f"Handshakes can take a few seconds. Check:  journalctl -u {instance} -n 30")
    return 0


# ── binary acquisition ───────────────────────────────────────────────────────────────────────
# Fetching a binary and putting it on PATH is the most dangerous thing this tool does, so it is
# the part written most conservatively.
#
#   * The version is PINNED, never "latest" — a moving target is not reproducible and is a supply
#     chain a partner cannot audit.
#   * Checksums are PINNED IN THIS FILE, not fetched alongside the download. A checksum retrieved
#     over the same channel as the artifact catches corruption but NOT a compromised release;
#     hard-coding what we observed makes a substituted artifact fail here.
#   * ⚠ Honest limit: these were observed from the published SHASUM256.txt on 2026-08-16 and are
#     trusted-on-first-observation. They are not a signature and this is not attestation. Verify
#     independently before this ships to anyone outside the fleet.
def _load_constants() -> dict:
    """Network facts come from network_constants.json — the ONE source both installers read.

    Inlining any of these again reintroduces the drift this file exists to prevent (the
    blocklist once shipped with four of its five entries). No fallback on purpose: running
    with a guessed blocklist or a guessed lighthouse is worse than not running.
    """
    for d in _persona_dirs() + [HERE]:
        f = d / "network_constants.json"
        if f.is_file():
            return json.loads(f.read_text())
    raise SystemExit(
        "network_constants.json not found next to the installer. It carries the blocklist, "
        "lighthouses and pinned checksums; refusing to run without it.")


C = _load_constants()


# Pinned release/signing key — MUST equal MINISIGN_PUBKEY in install.sh (release.sh verifies
# every cut against install.sh's copy, so a mismatch cannot ship silently).
MINISIGN_PUBKEY = "RWSKI+VKqsFhyMP0KFYiosvvf2mqJVcWKJ+m/SvwajdU9DnBGSvxBUyQ"
CONSTANTS_URL = "https://adna.network/network_constants.json"


def _refresh_constants() -> None:
    """Fetch the CURRENT signed network facts (lighthouse roster, blocklist, pins) and use them
    if the signature verifies against the pinned key. Any failure — offline, 404, bad bytes —
    means the payload's embedded copy stands. This is how a new lighthouse reaches every
    installer surface, including already-shipped versions, without a re-cut. A fetch that
    ARRIVES but fails verification is different: that gets a note, because a served-but-wrong
    signature on this endpoint should be seen."""
    global C, REQUEST_SCHEMA, NEBULA_MIN, NEBULA_PIN, NEBULA_SHA256
    try:
        import verify_minisig
        with tempfile.TemporaryDirectory() as td:
            fj = pathlib.Path(td) / "nc.json"
            fs = pathlib.Path(td) / "nc.json.minisig"
            for url, dst in ((CONSTANTS_URL, fj), (CONSTANTS_URL + ".minisig", fs)):
                with urllib.request.urlopen(url, timeout=10) as r:
                    dst.write_bytes(r.read())
            err = verify_minisig.verify_file(MINISIGN_PUBKEY, str(fj), str(fs))
            if err is not None:
                _note(f"served network_constants.json failed signature verification ({err}) — using the built-in copy")
                return
            fresh = json.loads(fj.read_text())
            if not (isinstance(fresh.get("lighthouses"), list) and fresh["lighthouses"]):
                _note("served network_constants.json has no lighthouse list — using the built-in copy")
                return
            C = fresh
            REQUEST_SCHEMA = C["request_schema"]
            NEBULA_MIN = tuple(C["nebula"]["min_version"])
            NEBULA_PIN = C["nebula"]["pin"]
            NEBULA_SHA256 = C["nebula"]["sha256"]
    except Exception:
        pass                      # offline or endpoint missing — the embedded copy stands


REQUEST_SCHEMA = C["request_schema"]
NEBULA_MIN = tuple(C["nebula"]["min_version"])
NEBULA_PIN = C["nebula"]["pin"]
NEBULA_SHA256 = C["nebula"]["sha256"]


def _asset_for(d: dict) -> str | None:
    if d["os_class"] == "macos":
        return "nebula-darwin.zip"
    arch = {"aarch64": "arm64", "arm64": "arm64", "x86_64": "amd64"}.get(d["machine"])
    return f"nebula-linux-{arch}.tar.gz" if arch else None


def acquire_nebula(d: dict, bindir: pathlib.Path, expect: str | None = None) -> int:
    _set_code("NET-01")
    """Download the PINNED release, verify against the PINNED hash, extract to bindir."""
    asset = _asset_for(d)
    if not asset:
        print(f"⛔ no published nebula build for {d['machine']} — cannot acquire automatically")
        return 1
    want = expect or NEBULA_SHA256.get(asset)
    if not want:
        print(f"⛔ no pinned checksum for {asset} — refusing to install an unverified binary "
              f"(pass --expect-sha256 if you have verified it yourself)")
        return 1

    url = f"https://github.com/slackhq/nebula/releases/download/{NEBULA_PIN}/{asset}"
    print(f"• fetching {NEBULA_PIN} {asset}")
    with tempfile.TemporaryDirectory() as td:
        blob = pathlib.Path(td) / asset
        try:
            with urllib.request.urlopen(url, timeout=60) as r, blob.open("wb") as f:
                shutil.copyfileobj(r, f)
        except (urllib.error.URLError, OSError) as e:
            print(f"⛔ download failed: {e}")
            return 1

        got = hashlib.sha256(blob.read_bytes()).hexdigest()
        if got != want:
            # Do not keep it, do not "try anyway". A mismatch is the check working.
            _set_code("SUM-02")
            print(f"⛔ CHECKSUM MISMATCH — refusing to install\n"
                  f"        expected {want}\n   got      {got}")
            return 1
        pass

        try:
            if asset.endswith(".zip"):
                import zipfile
                with zipfile.ZipFile(blob) as z:
                    z.extractall(td)
            else:
                with tarfile.open(blob) as t:
                    t.extractall(td)          # release archives are flat: ./nebula, ./nebula-cert
        except Exception as e:
            print(f"⛔ extract failed: {e}")
            return 1

        bindir.mkdir(parents=True, exist_ok=True)
        for name in ("nebula", "nebula-cert"):
            src = pathlib.Path(td) / name
            if not src.is_file():
                print(f"⛔ {name} missing from the archive")
                return 1
            dst = bindir / name
            try:
                shutil.copy2(src, dst)
                os.chmod(dst, 0o755)
            except PermissionError:
                print(f"⛔ cannot write {dst} — rerun with --bindir ~/bin, or with sudo")
                return 1
        print(f"✓ nebula + nebula-cert installed to {bindir}")
    return 0


# ── execute ──────────────────────────────────────────────────────────────────────────────────
def _instance_root(d: dict, instance: str, prefix: str | None) -> pathlib.Path:
    """Where this instance lives. --prefix makes the whole install relocatable, which is what
    allows a real execute run to be exercised on a LIVE node without touching its live instance."""
    if prefix:
        return pathlib.Path(prefix).expanduser() / instance
    if d["os_class"] == "macos":
        return pathlib.Path(d["brew_prefix"] or "/opt/homebrew") / "etc" / instance
    return pathlib.Path("/etc") / instance


def render_config(d: dict, persona: dict, root: pathlib.Path) -> str:
    net = persona["network"]
    relay_lines = "\n".join(f'    - "{h}"' for h in C["relays"])
    lh_lines = "\n".join(f'    - "{h}"' for h in C["lighthouses"])
    blocklist = "\n".join("    - " + f for f in C["blocklist"])
    shm = "\n".join(f'  "{k}": {json.dumps(v)}' for k, v in C["static_host_map"].items())
    listen = "0" if not net.get("inbound_required") else "REPLACE_AT_SIGNING"
    dev = C["overlay"]["tun_dev"].get(d["os_class"] or "linux", "nebula1043") or '""'
    return f"""pki:
  ca: {root}/pki/ca.crt
  cert: {root}/pki/host.crt
  key: {root}/pki/host.key
  blocklist:
{blocklist}

static_host_map:
{shm}

lighthouse:
  am_lighthouse: false
  interval: 60
  hosts:
{lh_lines}

listen:
  host: 0.0.0.0
  port: {listen}

relay:
  am_relay: false
  use_relays: true
  relays:
{relay_lines}

punchy:
  punch: true
  respond: true

tun:
  disabled: false
  dev: {dev}
  mtu: {C["overlay"]["mtu"]}

logging:
  level: info
  format: text

firewall:
  conntrack:
    tcp_timeout: {C["conntrack"]["tcp_timeout"]}
    udp_timeout: {C["conntrack"]["udp_timeout"]}
    default_timeout: {C["conntrack"]["default_timeout"]}
  outbound:
    - {{ port: any, proto: any, host: any }}
  inbound:
    - {{ port: any, proto: icmp, host: any }}
"""


def do_execute(d: dict, persona: dict, root: pathlib.Path, force: bool,
               bindir: pathlib.Path, expect: str | None = None,
               force_acquire: bool = False) -> tuple[int, str | None]:
    """Idempotent and refusing. Returns (exit_code, host_pub)."""
    pki = root / "pki"
    key, pub, cfg = pki / "host.key", pki / "host.pub", root / "config.yml"

    # _nebula_bins (bindir first) — same resolver, same precedence as detect()/activate().
    # Re-acquire whenever ANY of the pair is missing or the version is unknown/old: a
    # half-populated bindir or an unparseable -version must be repairable by rerun, not
    # carried forward as "adequate" (S349 review finding — need-gate treated unknown as fine).
    nebula_bin, cert_bin = _nebula_bins(bindir)
    need = (force_acquire or nebula_bin is None or cert_bin is None
            or d["nebula"] is None or d["nebula"] < NEBULA_MIN)
    if need:
        if acquire_nebula(d, bindir, expect):
            return 1, None
        cert_bin = str(bindir / "nebula-cert")
    else:
        pass

    try:
        pki.mkdir(parents=True, exist_ok=True)
    except PermissionError:
        print(f"⛔ cannot create {pki} — rerun with --prefix ~/somewhere, or with sudo")
        return 1, None

    # ⛔ NEVER regenerate over an existing private key. A new keypair silently invalidates every
    #    cert ever issued to this node, and the failure surfaces later as "your signature is wrong".
    if key.exists():
        if not pub.is_file():
            # A key with no pub is unrecoverable here: nebula-cert cannot re-derive the public
            # half, and continuing used to exit 0 WITHOUT emitting an enrollment request while
            # the double-click wrapper told the user to scroll up and copy one. Fail loudly.
            print(f"⛔ {key} exists but {pub} is MISSING — cannot rebuild the enrollment request.")
            print(f" Restore host.pub from a backup, or move the key file aside to generate a fresh pair.")
            return 1, None
        _note(f"existing keypair kept at {key} (an existing key is never overwritten)")
    else:
        # umask BEFORE keygen (Phase C1, research_security_2026-08 item 6): chmod-after-create
        # leaves a window where the key file exists readable. With umask 077 the file is born
        # 0600; the chmod below is a belt, not the mechanism. Parent dir tightened the same way.
        try:
            os.chmod(pki, 0o700)
        except OSError:
            pass  # not owner (e.g. sudo-created earlier) — the umask still protects the key file
        old_umask = os.umask(0o077)
        try:
            rc, out = _run([cert_bin, "keygen", "-out-key", str(key), "-out-pub", str(pub)])
        finally:
            os.umask(old_umask)
        if rc != 0:
            print(f"⛔ keygen failed: {out}")
            return 1, None
        os.chmod(key, 0o600)
        pass

    if cfg.exists() and not force:
        _note(f"existing config kept at {cfg} (--force overwrites)")
    else:
        cfg.write_text(render_config(d, persona, root))
        pass

    nebula_bin = nebula_bin if not need else str(bindir / "nebula")
    if nebula_bin:
        rc, out = _run([nebula_bin, "-test", "-config", str(cfg)])
        # Missing cert is the EXPECTED pre-signing state, not a failure.
        if rc == 0:
            pass
        elif "host.crt" in out or "no such file" in out.lower():
            pass
        else:
            _note(f"config check reported: {out.splitlines()[0][:100] if out else '?'}")

    host_pub = (_read(pub) or "").strip() or None
    return 0, host_pub


def load_persona(name: str) -> dict:
    tried = []
    for d in _persona_dirs():
        f = d / f"persona_{name}.json"
        tried.append(str(f))
        if f.is_file():
            return json.loads(_read(f) or "{}")
    sys.exit("no such persona: %s\nlooked in:\n %s\n(set ADNA_PERSONA_DIR to override)"
             % (name, "\n ".join(tried)))


def self_test() -> int:
    """Every refusal must be PROVEN to fire — a control never seen to refuse is not a control."""
    persona = {"persona": "developer", "requires_ratification": [],
               "network": {"mesh_join": True, "role": "dial_out_client", "inbound_required": False},
               "cert_request": {"groups": [], "duration_hours": 8760}, "graphs": []}
    base = {"os": "linux", "machine": "x86_64", "hostname": "t", "is_wsl": False, "is_rpi": False,
            "os_class": "linux", "systemd": True, "ntp_synced": True, "nebula": (1, 11, 0),
            "brew_prefix": None, "public_ip": "203.0.113.5", "cgnat": False}
    assert not preflight(base, persona)[0], "baseline must have no blockers"

    cases = {
        "32-bit":      ({**base, "machine": "armv7l"}, persona),
        "old nebula":  ({**base, "nebula": (1, 9, 3)}, persona),
        "clock skew":  ({**base, "ntp_synced": False}, persona),
        "cgnat+inbound": ({**base, "cgnat": True},
                          {**persona, "network": {**persona["network"], "inbound_required": True}}),
        "unratified":  (base, {**persona, "requires_ratification": ["R1"]}),
    }
    bad = 0
    for label, (dd, pp) in cases.items():
        blockers, _ = preflight(dd, pp)
        if blockers:
            print(f"✓ refuses on {label}: {blockers[0][:76]}")
        else:
            print(f"✗ {label} DID NOT REFUSE — the check is decorative"); bad += 1
    print(f"\nself-test: {len(cases)-bad}/{len(cases)} refusals proven")

    # Packaging gate — added after the Pi caught a false green here (2026-08-16). The refusal cases
    # above use inline dicts, so they pass even when persona files cannot be found at all. A
    # self-test that greens on an unusable package is worse than no self-test.
    try:
        load_persona("developer")
        print("✓ packaging: persona files resolve from this layout")
    except SystemExit as e:
        print(f"✗ packaging: personas NOT resolvable — {str(e).splitlines()[0]}")
        bad += 1

    # Plain-mode layer (B1): every symbol this file emits must have an ASCII mapping, and the
    # translation must actually strip it — known-bad first: an unmapped symbol must survive.
    src = pathlib.Path(__file__).read_text(encoding="utf-8")
    unmapped = {c for c in src if ord(c) > 127} - set(_PLAIN_MAP)
    sample = "✓ ok ⛔ err ⚠ warn • x → y".translate(str.maketrans(_PLAIN_MAP))
    if unmapped:
        print(f"✗ plain mode: symbol(s) with no ASCII mapping: {unmapped}"); bad += 1
    elif any(ord(c) > 127 for c in sample):
        print("✗ plain mode: translation left non-ASCII in output"); bad += 1
    elif "\u2605".translate(str.maketrans(_PLAIN_MAP)) != "\u2605":
        print("✗ plain mode: known-bad control failed (unmapped symbol vanished)"); bad += 1
    else:
        print("✓ plain mode: all emitted symbols mapped; translation yields pure ASCII")

    # Rerun-state layer (S349): every operator-caught bug this session was a "run twice, read
    # run 2" state-truth failure — detect() said nebula=absent about its OWN bindir install,
    # and a self-installed old nebula hit a HARD blocker whose remedy could not apply. The
    # refusal cases above cannot catch these (they assert what SHOULD stop; this asserts what
    # MUST NOT lie). Uses a fake bindir with an executable nebula stub; no network, no TPM.
    import tempfile as _tf
    with _tf.TemporaryDirectory() as _td:
        bd = pathlib.Path(_td)
        stub = bd / "nebula"
        stub.write_text("#!/bin/sh\necho 'Version: 1.11.0'\n")
        stub.chmod(0o755)
        # F-III-1: PATH-blind detect must find the bindir install, not report absent.
        import os as _os
        old_path = _os.environ.get("PATH", "")
        try:
            _os.environ["PATH"] = "/nonexistent-for-selftest"
            d_self = detect(bd)
        finally:
            _os.environ["PATH"] = old_path
        if d_self.get("nebula") != (1, 11, 0):
            print(f"✗ rerun-state: detect(bindir) reported nebula={d_self.get('nebula')} for a "
                  "bindir install (F-III-1 regression — the nebula=absent bug)"); bad += 1
        elif not d_self.get("nebula_self"):
            print("✗ rerun-state: bindir install not marked nebula_self (R2 upgrade path lost)"); bad += 1
        else:
            # R2: a self-installed BELOW-floor nebula must WARN (upgrade in place), never BLOCK.
            b_self, w_self = preflight({**base, "nebula": (1, 9, 0), "nebula_self": True}, persona)
            b_distro, _ = preflight({**base, "nebula": (1, 9, 0), "nebula_self": False}, persona)
            if b_self:
                print("✗ rerun-state: self-installed old nebula BLOCKS — unrecoverable rerun "
                      "loop (R2 regression)"); bad += 1
            elif not b_distro:
                print("✗ rerun-state: distro old nebula does NOT block — the real refusal was "
                      "lost while fixing R2"); bad += 1
            else:
                print("✓ rerun-state: bindir install detected + self-upgrade warns, distro blocks")
    return 1 if bad else 0


def self_audit() -> int:
    touched = [p for p in _READS if any(p.endswith(s) or s in p for s in _KEY_SUFFIXES)]
    if touched:
        print("✗ private-key-shaped path(s) read this run:"); [print("", t) for t in touched]
        return 1
    print(f"✓ self-audit clean — {len(_READS)} path(s) read, none private-key-shaped")
    return 0


# ── the code flow (Gangway A3) ───────────────────────────────────────────────────────────────
# An invite code makes the machine move the payload: the request auto-submits to the enrollment
# endpoint, the signed cert is fetched back, and the human relays at most BDWJ-HQPK-7NMR.
# NO NEW TRUST DECISIONS live here. The endpoint is a dumb queue; a human still signs every
# cert; and the received CA is verified against the fingerprint pinned in the installer payload
# (kubeadm-style) — a compromised endpoint can queue garbage but cannot redirect this node onto
# a different CA. No code → everything below is skipped and the paste flow runs exactly as today.

_CODE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"


def _canon_code(code: str) -> str | None:
    c = re.sub(r"[-\s]", "", code).upper()
    return c if len(c) == 12 and all(ch in _CODE_ALPHABET for ch in c) else None


def _http_json(method: str, url: str, body: dict | None = None) -> tuple[int, dict]:
    import urllib.error, urllib.request
    req = urllib.request.Request(url, method=method,
                                 data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Content-Type": "application/json",
                                          # Cloudflare 403s the default Python-urllib UA —
                                          # found live 2026-08-25, the code path had never
                                          # been exercised through urllib against prod
                                          "User-Agent": f"adna-install/{VERSION}"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read())
        except Exception:
            return e.code, {}
    except Exception as e:
        return 0, {"reason": "unreachable", "error": {
            "what": f"Could not reach the enrollment service at {url}.",
            "means": "Your install is fine; only the automatic hand-off failed.",
            "do": "Check your internet connection and rerun the same command, or send the "
                  "printed request by hand instead.", "help": ""}}


def _print_refusal(b: dict) -> None:
    e = b.get("error", {})
    print(f"\n⛔ {e.get('what', b.get('reason', 'refused'))}")
    for k in ("means", "do"):
        if e.get(k):
            print(f" {e[k]}")
    if e.get("help"):
        print(f" Help: {e['help']}")


def _enroll_endpoint() -> str:
    return os.environ.get("ADNA_ENROLL_URL") or C.get("enrollment", {}).get("endpoint_url", "")


def _received_ca_ok(ca_path: pathlib.Path, expected: str, nebula_cert: str) -> bool:
    """The received CA must match the fingerprint that shipped with this installer AND rode
    inside the signed invite. Checked BEFORE the file lands where activation will trust it."""
    certs = _cert_json(nebula_cert, ca_path)
    got = {c.get("fingerprint") for c in certs} if isinstance(certs, list) else \
        {certs.get("fingerprint")} if certs else set()
    return expected in got


def submit_uninvited(req: dict, root: pathlib.Path) -> dict | None:
    """No invite code: send the request to the operator's queue so nobody hand-carries JSON
    (operator direction 2026-08-25). Returns the saved state dict, or None — and None means
    the caller falls back to the paste block, which stays the offline path of last resort."""
    endpoint = _enroll_endpoint()
    pinned = C.get("enrollment", {}).get("ca_fingerprint", "")
    if not endpoint or not pinned:
        return None
    status, b = _http_json("POST", endpoint.rstrip("/") + "/request", req)
    if status != 200 or not isinstance(b, dict) or not b.get("request_id"):
        return None
    state = {"endpoint": endpoint, "request_id": b["request_id"],
             "ca_fingerprint": pinned, "uninvited": True,
             "submitted_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    try:
        (root / "uninvited_submission.json").write_text(json.dumps(state, indent=2) + "\n")
    except OSError:
        pass          # unsaved state only costs the rerun shortcut, not the submission
    return state


def submit_enrollment(req: dict, code: str, root: pathlib.Path) -> dict | None:
    _set_code("SRV-01")
    """POST the request against the code. Returns the saved state dict, or None (caller
    falls back to the paste flow — a dead endpoint must never strand an install)."""
    endpoint = _enroll_endpoint()
    if not endpoint:
        print("\n• invite code noted, but this installer has no enrollment endpoint "
              "configured yet — falling back to the copy-paste hand-off below.")
        return None
    pinned = C.get("enrollment", {}).get("ca_fingerprint", "")
    # F-S380-01: the payload pin is the ONLY client-side trust anchor in the code flow. With
    # an empty pin the client would silently adopt whatever fingerprint the endpoint returns,
    # turning endpoint compromise into CA substitution. Hard-fail — no paste fallback (the
    # payload is malformed, not the endpoint dead) — and BEFORE the POST, so a broken payload
    # never burns an invite use.
    if not pinned:
        raise SystemExit(
            "\n⛔ this installer payload carries no CA fingerprint pin, so it cannot verify\n"
            "      the certificate authority it would receive. This payload is malformed or\n"
            "      was never released — re-download the installer; do not retry with this one.")
    status, b = _http_json("POST", endpoint.rstrip("/") + "/enroll",
                           {"code": code, "request": req})
    if status != 200:
        _print_refusal(b)
        return None
    invite = b.get("invite", {})
    inv_fp = invite.get("network", {}).get("ca_fingerprint", "")
    # Bidirectional trust: the invite's CA fingerprint must agree with the one pinned in
    # this payload. A mismatch means the endpoint (or the invite) is not for this network.
    if inv_fp and inv_fp != pinned:
        print("\n⛔ the enrollment service returned an invite for a DIFFERENT certificate")
        print(" authority than this installer was built for. Refusing to continue —")
        print(" report this to whoever invited you; do not retry.")
        return None
    state = {"request_id": b["request_id"], "code_sha256": hashlib.sha256(code.encode()).hexdigest(),
             "endpoint": endpoint, "ca_fingerprint": pinned,
             "submitted_at": time.strftime("%Y-%m-%dT%H:%M:%S")}
    (root / "enrollment_submission.json").write_text(json.dumps(state, indent=2) + "\n")
    print("\n✓ enrollment request submitted.")
    return state


def poll_enrollment(state: dict, root: pathlib.Path, bindir: pathlib.Path,
                    instance: str, waits: int = 6, wait_s: int = 10) -> int:
    """Poll for the signed cert. Resumable and idempotent: rerunning the same command lands
    back here and just checks again."""
    _set_code("SRV-02")
    url = state["endpoint"].rstrip("/") + "/enroll/" + state["request_id"]
    pki = root / "pki"
    if (pki / "ca.crt").exists() and (pki / "host.crt").exists():
        print("\n✓ certificates already delivered and verified. Next:")
        print(f"{sys.executable} {_self_for_resume(root)} --activate "
              f"--prefix {root.parent} --instance {instance} --bindir {bindir} --execute")
        return 0
    for attempt in range(waits):
        status, b = _http_json("GET", url)
        if status != 200:
            _print_refusal(b)
            return 1
        st = b.get("state")
        if st == "queued":
            if attempt == 0:
                print("\nSubmitted. Waiting for approval — a person reviews every request.")
                print("Safe to close this window; rerun the same command later to check.")
            time.sleep(wait_s)
            continue
        if st == "uninvited":
            print("\nYour request is with the network operator, waiting for review.")
            print("Rerun this same command any time to check; approval completes automatically.")
            return 0
        if st == "refused":
            print(f"\n⛔ your enrollment request was refused: {b.get('reason', 'no reason given')}")
            print(" Contact the person who invited you.")
            return 1
        if st == "picked_up":
            # Legacy state (pre-two-phase Worker rows). The old advice here — "rerun with a
            # fresh invite code" — was a dead end for the codeless flow, whose users have no
            # code and no way to get one (hit live by the first two real enrollees).
            print("\n⛔ this request's certificates were already collected, but they are not")
            print(" on this machine.")
            if state.get("uninvited"):
                print(" This is a fault on our side, not yours. Contact the network operator —")
                print(" they can re-stage the certificates for this same request; then just")
                print(" rerun this command.")
            else:
                print(" Ask the person who invited you for a fresh code, or ask the network")
                print(" operator to re-stage this request's certificates.")
            return 1
        if st == "delivered":
            print("\n⛔ this machine already received and confirmed its certificates, but they")
            print(" are not in place here now. Contact the network operator to re-stage them;")
            print(" then rerun this command.")
            return 1
        if st == "ready":
            nebula_cert = _nebula_bins(bindir)[1] or str(bindir / "nebula-cert")
            pki.mkdir(parents=True, exist_ok=True)
            tmp_ca = pki / "ca.crt.incoming"
            tmp_ca.write_text(b["ca_crt"])
            if not _received_ca_ok(tmp_ca, state["ca_fingerprint"], nebula_cert):
                tmp_ca.unlink(missing_ok=True)
                print("\n⛔ the certificate authority we received DOES NOT MATCH the one this")
                print(" installer was built to trust. Refusing to install it. Report this")
                print(" to whoever invited you; do not retry.")
                return 1
            tmp_ca.rename(pki / "ca.crt")
            (pki / "host.crt").write_text(b["host_crt"])
            # Confirm delivery AFTER the certs are safe on disk — the ack is what consumes
            # the staged copy on the Worker (two-phase pickup; F-S352L-01). Best-effort:
            # a failed ack costs nothing here, the certs stay re-fetchable server-side.
            if b.get("ack_token"):
                ack_status, _ = _http_json("POST", url + "/ack", {"ack_token": b["ack_token"]})
                if ack_status != 200:
                    print("⚠ could not confirm delivery back to the enrollment service — "
                          "harmless; your certificates are already safe on this machine.")
            print("\n✓ approved! certificates received and verified against the pinned CA.")
            print("One step left (it needs root, to create the network device):\n")
            print(f"sudo {sys.executable} {_self_for_resume(root)} --activate \\")
            print(f"  --prefix {root.parent} --instance {instance} --bindir {bindir} --execute\n")
            return 0
        print(f"\n⛔ unexpected state from the enrollment service: {st!r}")
        return 1
    print("\nStill waiting for approval — a person signs every request.")
    print("Safe to close this window; rerun the same command later to check.")
    return 0


def main() -> int:
    """Run the installer; on any failure, close with the four-layer block's layers 2-4."""
    try:
        rc = _main()
    except SystemExit as e:
        rc = e.code if isinstance(e.code, int) else (0 if e.code is None else 1)
    except KeyboardInterrupt:
        print(f"\nStopped by you. {MSG_RERUN}")
        return 130
    if rc and _EPILOGUE:
        _fail_epilogue()
    return rc or 0


def _main() -> int:
    ap = argparse.ArgumentParser(description="adna_install — node onboarding, no agent required.")
    ap.add_argument("--profile", default="developer", help="persona name (default: developer)")
    ap.add_argument("--execute", action="store_true", help="actually change this machine (default: dry-run)")
    ap.add_argument("--json", action="store_true", help="print the enrollment request as JSON")
    ap.add_argument("--online", action="store_true", help="opt-in: look up the public IP (CGNAT check)")
    ap.add_argument("--instance", default="nebula-1043",
                    help="instance dir name (default nebula-1043 — the LIVE one; use another for a test run)")
    ap.add_argument("--prefix", help="relocate the whole install under this dir (no sudo, touches no live instance)")
    ap.add_argument("--force", action="store_true", help="overwrite an existing config (never a key)")
    ap.add_argument("--bindir", help="where to install the nebula binaries (default /usr/local/bin)")
    ap.add_argument("--activate", action="store_true",
                    help="second step: after your signed certificate arrives, verify it and start the service")
    ap.add_argument("--second-identity", action="store_true",
                    help="emit an enrollment request even though this machine already holds an overlay address (a deliberate second identity)")
    ap.add_argument("--no-workspace", action="store_true",
                    help="skip cloning the aDNA workspace (the network install is unaffected)")
    ap.add_argument("--force-acquire", action="store_true", help="download nebula even if a good one is present (test the supply-chain gate)")
    ap.add_argument("--expect-sha256", dest="expect", help="override the pinned checksum (you have verified it yourself)")
    ap.add_argument("--code", help="invite code (like BDWJ-HQPK-7NMR) — submits the enrollment "
                                   "request automatically and fetches the cert when approved; "
                                   "without it, the request is printed to send by hand")
    ap.add_argument("--self-test", action="store_true")
    ap.add_argument("--self-audit", action="store_true")
    ap.add_argument("--plain", action="store_true",
                    help="ASCII-only output (also on when NO_COLOR is set, TERM=dumb, or output is piped)")
    a = ap.parse_args()

    dev_mode = a.self_test or a.self_audit
    if dev_mode:
        global _EPILOGUE
        _EPILOGUE = False
    _install_output(_plain_wanted(a.plain), None if dev_mode else LOG_FILE)

    if a.self_test:
        return self_test()

    code = None
    if a.code:
        code = _canon_code(a.code)
        if not code:
            _set_code("COD-01")
            print("⛔ that invite code is not in the right shape. Codes look like BDWJ-HQPK-7NMR")
            print("— twelve letters and digits. Dashes and capitals do not matter; every")
            print("character does. Copy it exactly as it was given to you and try again.")
            return 1

    if a.execute or a.online:
        _refresh_constants()
    persona = load_persona(a.profile)
    bindir = pathlib.Path(a.bindir).expanduser() if a.bindir else pathlib.Path("/usr/local/bin")
    d = detect(bindir)
    if a.online:
        public_ip(d)

    print(f"adna_install {VERSION} · persona '{persona['persona']}'")
    print(f"detected: {d['os_class']} · {d['machine']} · "
          f"{'WSL2 · ' if d['is_wsl'] else ''}{'RaspberryPi · ' if d['is_rpi'] else ''}"
          f"nebula={'.'.join(map(str,d['nebula'])) if d['nebula'] else 'absent'} · "
          f"systemd={'yes' if d['systemd'] else 'no'}\n")

    blockers, warns = preflight(d, persona)
    for w in warns:
        print(f"⚠ {w}\n")
    if blockers:
        _set_code("SYS-10")
        print("⛔ Cannot install:\n")
        for b in blockers:
            print(f"• {b}\n")
        return 1

    if a.activate:
        return activate(d, _instance_root(d, a.instance, a.prefix), a.instance,
                        bindir, dry=not a.execute)

    # Already-enrolled short-circuit (operator feedback, 2026-08-23): a machine that is on the
    # network gets three lines and a clean exit, not the whole 7-step plan of no-ops. --force
    # (repair), --second-identity, and --activate (handled above) still take the full path.
    if d.get("overlay_ip") and not a.second_identity and not a.force:
        # An overlay ADDRESS is only a claim — prove membership with a lighthouse handshake,
        # and say whichever half is actually true (operator finding, 2026-08-23).
        lh, n_lh = _reach_overlay()
        if lh:
            print(f"✓ Already on the network ({d['overlay_ip']} — lighthouse {lh} answered).")
        else:
            print(f"⚠ This machine holds overlay address {d['overlay_ip']} but is NOT on the "
                  f"network (none of {n_lh} lighthouses answered).")
            print(f"Check the service:  journalctl -u nebula-1043 -n 30")
        print("Nothing was changed. Second identity: --second-identity. Repair files: --force.")
        return 0

    steps = plan(d, persona, a.instance, a.prefix, bindir)
    if not a.execute:
        # Dry run: the plan IS the product — show every intended row, numbered for a
        # screen-reader listener (research_accessibility_2026-08 §5).
        print("PLAN:")
        total = sum(1 for s in steps if not s.startswith("***"))
        n = 0
        for s in steps:
            if s.startswith("***"):
                print(f"{s}")
            else:
                n += 1
                print(f"Step {n} of {total}: {s}")
    else:
        # Real run: no plan dump, no step scaffolding (clig.dev: keep it brief) — each action
        # prints one line as it happens, so the output IS the timeline. Banners still lead.
        for s in steps:
            if s.startswith("***"):
                print(f"{s}")

    host_pub = None
    if a.execute:
        root = _instance_root(d, a.instance, a.prefix)
        if a.instance == "nebula-1043" and not a.prefix:
            print(f"\n⚠ targeting the LIVE instance at {root}. Use --instance/--prefix for a test run.")
        rc, host_pub = do_execute(d, persona, root, a.force, bindir, a.expect, a.force_acquire)
        if rc:
            return rc
        _persist_payload(root.parent)

    workspace = None
    if a.execute:
        workspace = setup_workspace(a.no_workspace)

    req = enrollment_request(d, persona, host_pub=host_pub)

    if not a.execute:
        print("\n(dry run — nothing was changed. re-run with --execute)")
        if a.json:
            print("\n" + json.dumps(req, indent=2))
    elif host_pub and d.get("overlay_ip") and not a.second_identity:
        print(f"\nNothing else to do — this machine already holds overlay address {d['overlay_ip']}.")
        print("Joining again would create a second identity (--second-identity if you mean to).")
    elif host_pub and code:
        # The code flow (Gangway A3): the machine moves the payload. Resumable — a rerun with
        # the same code skips the re-submit and just checks status. If the endpoint cannot be
        # reached, fall THROUGH to the paste flow below: a dead queue never strands an install.
        state = None
        state_file = root / "enrollment_submission.json"
        if state_file.exists():
            prior = json.loads(state_file.read_text())
            if prior.get("code_sha256") == hashlib.sha256(code.encode()).hexdigest():
                state = prior      # same code, same request — resume, don't burn another use
        if state is None:
            state = submit_enrollment(req, code, root)
        if state is not None:
            return poll_enrollment(state, root, bindir, a.instance)
        code = None                # endpoint unavailable — the paste flow takes over
    if host_pub and not code and a.execute and not (d.get("overlay_ip") and not a.second_identity):
        sub_file = root / "uninvited_submission.json"
        u_state = None
        if sub_file.exists():
            try:
                u_state = json.loads(sub_file.read_text())
            except (OSError, json.JSONDecodeError):
                u_state = None
        if u_state:
            return poll_enrollment(u_state, root, bindir, a.instance, waits=1, wait_s=0)
        u_state = submit_uninvited(req, root)
        if u_state:
            print("\n✓ Enrollment request sent to the network operator.")
            print("Rerun this same command any time to check; approval completes automatically.")
            code = "SENT"        # suppresses the paste block below; nothing else reads it
    if host_pub and not code and a.execute and not (d.get("overlay_ip") and not a.second_identity):
        # The whole point of a run is to produce the thing you send back, so it is ALWAYS
        # printed on a real install — it used to appear only under --json, which meant the
        # click-installer told people to send a block that was never shown to them.
        # Delimited with the `=====` ruler, so
        # "copy from here to here" is unambiguous for someone who does not read terminals.
        body = json.dumps(req, indent=2)
        out = root / "enrollment_request.json"
        try:
            out.write_text(body + "\n")
            saved = f"Also saved to: {out}\n(you can attach that file instead of copying)"
        except OSError as e:
            saved = f"(could not save a copy: {e} — copy the text above instead)"

        # End-of-run shape (clig.dev): say what changed, then the next command — invite code
        # first, the paste block as the no-code fallback. Operator direction 2026-08-23:
        # enrollment should ride invites; flip the block behind a flag once the enrollment
        # endpoint is armed (MASTER_INVITE_PUBKEY_HEX) and codes are the live path.
        print("\n✓ aDNA node installed\n")
        print(f"Version:   {VERSION}")
        print(f"Keys:      {root / 'pki'}  (private key never leaves this machine)")
        print(f"Workspace: {workspace or 'not installed'}")
        if _NOTES:
            print("\n⚠ Notes:")
            for n_ in _NOTES:
                print(f"• {n_}")
        print("\nNext: have an invite code? Run  adna-install --code XXXX-XXXX-XXXX  (safe to rerun).")
        print("No code? Send the block below to whoever invited you. It contains your")
        print("PUBLIC key only — nothing secret.\n")
        print("=" * 72)
        print("ENROLLMENT REQUEST — copy everything between these two lines")
        print("=" * 72)
        print(body)
        print("=" * 72)
        print("END ENROLLMENT REQUEST")
        print("=" * 72)
        print(saved)
    if a.json and not workspace:
        print("\n" + json.dumps(req, indent=2))
    if a.self_audit:
        print()
        return self_audit()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
