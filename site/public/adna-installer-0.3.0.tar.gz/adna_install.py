#!/usr/bin/env python3
"""adna_install.py — the doing half of node onboarding. No agent required.

Companion to `what/network/health/node_doctor/node_doctor.py`, which is the *measuring* half and
already ships agent-free. This adds: detect → refuse-or-plan → install → keygen → config → emit an
enrollment request. It deliberately STOPS before enrollment completes (see §Enrollment).

Design constraints, each earned:

* **Pure stdlib.** Same constraint node_doctor is written to. A partner should not need pip.
* **Dry-run by default.** `--execute` is required to change anything. A tool that mutates a partner's
  machine on first invocation is not a tool a partner should trust.
* **Refuse clearly, never improvise.** Every known trap below cost a real onboarding.
* **The private key is born here and never leaves.** Nothing in this file prints, copies or transmits
  a `.key`. `--self-audit` proves it.
* **No dependency on the signer existing.** Ruling C (2026-08-16) chose scoped auto-signing, but the
  capability is not granted yet, so this emits a request and stops. Human-in-loop today, signer-ready
  later, one interface either way.

Traps encoded (platform, source):
  armv7l / 32-bit ARM   → refuse           (a 64-bit OS is required; 32-bit Pi images cannot join)
  distro nebula 1.9.x   → refuse           (v1-only certs cannot join a v2 mesh; distro packages ship 1.9.x)
  NTP not synced        → refuse           (handshakes silently fail)
  no systemd            → warn + alt path  (WSL2 distros vary)
  WSL2 shared netns     → forbid net.*     (all distros share one netns; a sysctl would hit the host)
  Raspberry Pi OS       → measure sshd     (a key-only claim must be measured, never assumed)
  CGNAT + inbound role  → refuse           (a port-forward cannot work behind carrier-grade NAT)

Usage:
    python3 adna_install.py --profile developer                 # dry-run plan
    python3 adna_install.py --profile developer --execute       # actually do it
    python3 adna_install.py --self-test                         # prove the refusals fire
    python3 adna_install.py --self-audit                        # prove no private key was read
"""
from __future__ import annotations
import argparse, hashlib, json, os, platform, re, shutil, socket, subprocess, sys, tarfile, tempfile, pathlib
import urllib.request, urllib.error

VERSION = "0.3.0"
HERE = pathlib.Path(__file__).resolve().parent
# Persona lookup must work for BOTH shapes this file ships in: inside the vault tree, and as a FLAT
# COPY beside its personas (which is how a partner receives it, and how a curl-installer will lay it
# down). Resolving only vault-relative broke on the Pi at first real test — and the self-test did not
# catch it, because self-test uses inline dicts and never loads a persona file. Ordered candidates:
def _persona_dirs() -> list[pathlib.Path]:
    env = os.environ.get("ADNA_PERSONA_DIR")
    return [d for d in [
        pathlib.Path(env).expanduser() if env else None,   # explicit override wins
        HERE / "persona_profiles",                          # flat copy — the partner shape
        HERE,                                               # personas dropped beside the script
        HERE.parents[1] / "profiles" / "persona_profiles",  # in-vault
    ] if d]

_KEY_SUFFIXES = (".key", ".pem", "id_ed25519", "id_rsa")
_READS: list[str] = []          # every path this run opened — for --self-audit


def _read(path: pathlib.Path) -> str | None:
    _READS.append(str(path))
    try:
        return path.read_text(errors="ignore")
    except Exception:
        return None


def _run(cmd: list[str], timeout: int = 20) -> tuple[int, str]:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout + p.stderr).strip()
    except FileNotFoundError:
        return 127, "not found"
    except subprocess.TimeoutExpired:
        return 124, "timeout"


# ── detect ───────────────────────────────────────────────────────────────────────────────────
def detect() -> dict:
    d: dict = {
        "os": sys.platform, "machine": platform.machine(),
        "hostname": socket.gethostname().split(".")[0],
        "is_wsl": False, "is_rpi": False, "os_class": None,
        "systemd": False, "ntp_synced": None, "nebula": None,
        "brew_prefix": None, "public_ip": None, "cgnat": None,
    }
    rel = (_read(pathlib.Path("/proc/version")) or "").lower()
    d["is_wsl"] = "microsoft" in rel
    model = _read(pathlib.Path("/proc/device-tree/model")) or ""
    osrel = _read(pathlib.Path("/etc/os-release")) or ""
    d["is_rpi"] = "raspberry pi" in (model + osrel).lower()

    if sys.platform == "darwin":
        d["os_class"] = "macos"
        rc, out = _run(["brew", "--prefix"])
        d["brew_prefix"] = out if rc == 0 else None
    elif sys.platform.startswith("linux"):
        d["os_class"] = "wsl2" if d["is_wsl"] else "linux"
    elif sys.platform.startswith("win"):
        d["os_class"] = "windows"

    d["systemd"] = pathlib.Path("/run/systemd/system").exists()

    rc, out = _run(["timedatectl", "show", "-p", "NTPSynchronized", "--value"])
    if rc == 0:
        d["ntp_synced"] = out.strip() == "yes"

    if shutil.which("nebula"):
        rc, out = _run(["nebula", "-version"])
        m = re.search(r"(\d+)\.(\d+)\.(\d+)", out)
        if m:
            d["nebula"] = tuple(int(x) for x in m.groups())
    return d


def public_ip(d: dict) -> None:
    rc, out = _run(["curl", "-fsS", "--max-time", "6", "https://api.ipify.org"])
    if rc == 0 and re.fullmatch(r"[\d.]+", out.strip()):
        ip = out.strip()
        d["public_ip"] = ip
        first, second = (int(x) for x in ip.split(".")[:2])
        d["cgnat"] = first == 100 and 64 <= second <= 127


# ── refuse or plan ───────────────────────────────────────────────────────────────────────────
def preflight(d: dict, persona: dict) -> tuple[list[str], list[str]]:
    """Returns (blockers, warnings). A blocker means STOP — do not improvise around it."""
    blockers: list[str] = []
    warns: list[str] = []
    inbound = persona["network"].get("inbound_required", False)

    if d["machine"] in ("armv7l", "armv6l", "i386", "i686"):
        blockers.append(
            f"32-bit platform ({d['machine']}). This mesh needs a 64-bit OS — on a Pi that means "
            "re-imaging with 64-bit Raspberry Pi OS. Nothing here will work until then.")

    if d["nebula"] and d["nebula"] < NEBULA_MIN:
        v = ".".join(map(str, d["nebula"]))
        blockers.append(
            f"nebula {v} is installed and is too old (need >= {'.'.join(map(str, NEBULA_MIN))}). "
            "Distro packages ship 1.9.x, which speaks the v1 certificate format and CANNOT join this "
            "mesh. Remove it and install the official release.")

    if d["ntp_synced"] is False:
        blockers.append(
            "system clock is not NTP-synced. Nebula handshakes fail against a skewed clock, and the "
            "failure looks like a network problem. Fix: sudo timedatectl set-ntp true")

    if inbound and d["cgnat"]:
        blockers.append(
            f"this network is behind CGNAT (public IP {d['public_ip']}), and the chosen persona needs "
            "an inbound port. A port-forward cannot work — the address is not really yours. Use a "
            "client role instead; nothing else about the install changes.")

    if d["os_class"] in ("linux", "wsl2") and not d["systemd"]:
        warns.append("systemd not detected — the service step will need the init-script variant.")

    if d["is_wsl"]:
        warns.append(
            "WSL2: all distros on this host SHARE ONE NETWORK NAMESPACE, so this installer will not "
            "write any net.* sysctl. Boot ordering is handled with a systemd drop-in.")

    if d["is_rpi"]:
        rc, out = _run(["sshd", "-T"])
        pw = "passwordauthentication yes" in out.lower()
        warns.append(
            "Raspberry Pi OS: sshd password authentication is "
            + ("ON — measured, not assumed. " if pw else "off (measured). ")
            + "This installer opens no inbound SSH; if you later add one, turn password auth off first.")

    if persona.get("requires_ratification"):
        blockers.append(
            f"persona '{persona['persona']}' has {len(persona['requires_ratification'])} unratified "
            "decision(s) and may not be installed yet.")
    return blockers, warns


# ── plan ─────────────────────────────────────────────────────────────────────────────────────
def nebula_source(d: dict) -> str:
    if d["os_class"] == "macos":
        return "brew install nebula"
    arch = {"aarch64": "arm64", "arm64": "arm64", "x86_64": "amd64"}.get(d["machine"], d["machine"])
    return f"github release nebula-linux-{arch}.tar.gz → /usr/local/bin  (NOT the distro package)"


def pki_dir(d: dict, instance: str = "nebula-1043", prefix: str | None = None) -> str:
    # Must agree with _instance_root(). A plan that prints one path and writes another is the
    # "confident, specific, wrong" class — caught on the first real --execute run (2026-08-16).
    return str(_instance_root(d, instance, prefix) / "pki")


def plan(d: dict, persona: dict, instance: str = "nebula-1043", prefix: str | None = None) -> list[str]:
    net = persona["network"]
    steps = [
        f"install nebula        : {nebula_source(d)}",
        f"keypair (born here)   : {pki_dir(d, instance, prefix)}/host.key  (0600, never leaves this machine)",
        f"config                : role={net['role']}  mesh_join={net['mesh_join']}  "
        f"listen_port={'fixed' if net.get('inbound_required') else '0 (dial-out)'}",
        f"cert request          : groups={persona['cert_request']['groups'] or '[] (minimal privilege)'}  "
        f"duration={persona['cert_request']['duration_hours']}h",
        f"graphs to fetch       : {len(persona['graphs'])} "
        f"({sum(1 for g in persona['graphs'] if g['class']=='private')} deferred until forge sign-in)",
        f"aDNA workspace        : clone to {C['workspace']['clone_target']} (optional; --no-workspace to skip)",
        "enrollment            : emit request, then STOP (see below)",
    ]
    if not net["mesh_join"]:
        steps.insert(0, "*** LOCAL-ONLY PROFILE — this node will not join the mesh and transmits nothing ***")
    return steps


def enrollment_request(d: dict, persona: dict, host_pub: str | None) -> dict:
    return {
        "schema": REQUEST_SCHEMA,
        "installer_version": VERSION,
        "persona": persona["persona"],
        "node": {
            "hostname": d["hostname"], "os_class": d["os_class"], "machine": d["machine"],
            "is_wsl": d["is_wsl"], "is_rpi": d["is_rpi"],
            "nebula": ".".join(map(str, d["nebula"])) if d["nebula"] else None,
            "public_ip": d["public_ip"], "cgnat": d["cgnat"],
        },
        "cert_request": {
            **persona["cert_request"],
            # Ruling C (2026-08-16): auto-signable ONLY when it has earned it.
            "auto_signable": (
                not persona["cert_request"]["groups"]
                and not persona["network"].get("inbound_required", False)
                and persona["network"]["role"] in ("dial_out_client", "relay_client", "none")
            ),
        },
        "host_pub": host_pub,
        "note": "PUBLIC key only. No private key material appears in this document, by construction.",
    }



def setup_workspace(skip: bool) -> str | None:
    """Clone the aDNA workspace. Optional, non-fatal, and never requires Claude Code.

    Unifying the two installs (operator ruling, 2026-08-16) means one command both joins the
    network and gives you the workspace. They stay INDEPENDENT goods: the mesh works with no
    workspace, the workspace works with no mesh, and neither needs an AI assistant. The site
    previously advertised `git clone ... && cd ~/aDNA && claude` as canonical, which made Claude
    Code a hard dependency of getting started; that trailing `claude` is exactly what this
    replaces.

    Never clobbers an existing directory, and a failure here does NOT fail the install -- the
    network half is the part with a human waiting on the other end.
    """
    w = C["workspace"]
    target = pathlib.Path(w["clone_target"].replace("~", str(pathlib.Path.home())))
    if skip:
        print(f"   • workspace: skipped (--no-workspace). Get it later with:  git clone {w['canonical_repo_git']} {w['clone_target']}")
        return None
    if target.exists():
        print(f"   ✓ workspace already at {target} — left untouched (never overwritten)")
        return str(target)
    if not shutil.which("git"):
        print("   • workspace: SKIPPED, git is not installed. The network half is unaffected.")
        print(f"     Install git, then:  git clone {w['canonical_repo_git']} {w['clone_target']}")
        return None

    print(f"   • cloning the aDNA workspace to {target}")
    rc, out = _run(["git", "clone", "--depth", "1", w["canonical_repo_git"], str(target)], timeout=300)
    if rc != 0:
        # Non-fatal by design. Someone is waiting to approve the enrollment request; do not
        # throw that away because a git clone failed.
        print(f"   ⚠ workspace clone FAILED (the network install is unaffected): {out.splitlines()[-1] if out else rc}")
        print(f"     Retry later:  git clone {w['canonical_repo_git']} {w['clone_target']}")
        return None
    print(f"   ✓ workspace cloned to {target}")
    return str(target)


# ── activate ─────────────────────────────────────────────────────────────────────────────────
# The SECOND command. First run produces an enrollment request and stops; a human signs it and
# sends back ca.crt + host.crt; this turns those into a running node.
#
# Split deliberately, for two reasons. There is no certificate at first-install time, so a service
# started then would only crash-loop. And this is the ONLY step that needs root — keeping it apart
# is what lets the first command stay honestly no-privilege.

def _cert_json(nebula_cert: str, path: pathlib.Path) -> dict | None:
    rc, out = _run([nebula_cert, "print", "-json", "-path", str(path)])
    if rc != 0:
        return None
    try:
        d = json.loads(out)
        return d[0] if isinstance(d, list) else d
    except (json.JSONDecodeError, IndexError):
        return None


def _pub_hex(path: pathlib.Path) -> str | None:
    """Public key from a nebula .pub file, as hex — the form the cert reports it in."""
    import base64
    txt = _read(path)
    if not txt:
        return None
    body = "".join(l for l in txt.splitlines() if "-----" not in l).strip()
    try:
        return base64.b64decode(body).hex()
    except Exception:
        return None


def cert_gates(root: pathlib.Path, nebula_cert: str) -> list[str]:
    """Everything that must be true before a service is worth starting. Blockers, in order."""
    bad: list[str] = []
    ca, crt, pub = root / "pki/ca.crt", root / "pki/host.crt", root / "pki/host.pub"

    missing = [str(f) for f in (ca, crt) if not f.is_file()]
    if missing:
        bad.append("the signed certificate has not arrived yet. Save the two files you were sent as:\n"
                   f"       {ca}\n       {crt}\n"
                   "     then run this again. (Nothing else is needed — your private key is already here.)")
        return bad

    # A1 — signed by a CA we trust. Catches a cert minted by the wrong authority entirely.
    rc, out = _run([nebula_cert, "verify", "-ca", str(ca), "-crt", str(crt)])
    if rc != 0:
        bad.append(f"certificate does not verify against {ca}:\n       {out.splitlines()[0] if out else rc}")

    info = _cert_json(nebula_cert, crt)
    if not info:
        bad.append(f"could not read {crt} — it may be truncated or not a nebula certificate")
        return bad

    # A2 — THE KEY-BINDING GATE. A certificate that verifies against the CA can still
    # have been issued for somebody else's public key: it would be perfectly valid and useless,
    # and nebula's failure mode is a silent non-handshake that looks like a network problem.
    # Compare what the CA signed against the key that was actually born on this machine.
    cert_pub, have_pub = info.get("publicKey"), _pub_hex(pub)
    if not have_pub:
        bad.append(f"cannot read {pub} — needed to prove the certificate was issued for THIS machine's key")
    elif cert_pub != have_pub:
        bad.append("CERTIFICATE / KEY MISMATCH — this certificate was issued for a different key.\n"
                   f"       certificate carries : {cert_pub}\n"
                   f"       this machine's key  : {have_pub}\n"
                   "     It would verify against the CA and still never connect. Ask for a certificate\n"
                   "     issued against the enrollment request from THIS machine.")

    det = info.get("details", {})
    # A3 — validity window. An expired cert fails as a silent non-handshake too.
    na = det.get("notAfter", "")
    if na:
        try:
            import datetime as _dt
            exp = _dt.datetime.fromisoformat(na)
            now = _dt.datetime.now(exp.tzinfo)
            if exp <= now:
                bad.append(f"certificate EXPIRED on {na}. Request a new one.")
            elif (exp - now).days < 30:
                print(f"   ⚠ certificate expires in {(exp - now).days} day(s) ({na}) — plan a renewal")
        except ValueError:
            pass

    # A4 — the address is inside our overlay. A cert for the wrong network joins nothing.
    nets = det.get("networks") or []
    want = C["overlay"]["cidr"].rsplit(".", 2)[0]
    if nets and not any(n.startswith(want) for n in nets):
        bad.append(f"certificate address {nets} is outside this overlay ({C['overlay']['cidr']})")
    return bad


def render_service(d: dict, root: pathlib.Path, nebula_bin: str, instance: str) -> tuple[str, str, str]:
    """Return (kind, install_path, contents) for this platform's service manager."""
    if d["os_class"] == "macos":
        label = f"network.adna.{instance}"
        return ("launchd", f"/Library/LaunchDaemons/{label}.plist", f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>{label}</string>
  <key>ProgramArguments</key>
  <array>
    <string>{nebula_bin}</string>
    <string>-config</string>
    <string>{root}/config.yml</string>
  </array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>/var/log/{instance}.log</string>
  <key>StandardErrorPath</key><string>/var/log/{instance}.err.log</string>
</dict>
</plist>
""")
    # systemd. Type=simple rather than notify: notify needs nebula built with sd-notify support
    # and fails closed as a startup timeout if it is not there. simple always works.
    return ("systemd", f"/etc/systemd/system/{instance}.service", f"""[Unit]
Description=Nebula overlay ({instance}) — aDNA lattice
Documentation=https://adna.network/install
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart={nebula_bin} -config {root}/config.yml
Restart=always
RestartSec=5
SyslogIdentifier={instance}
# Modest hardening. NOT ProtectSystem=strict or PrivateTmp: nebula needs to create a tun device
# and read its pki, and a broken sandbox here presents as a mesh outage that is painful to trace.
NoNewPrivileges=yes
ProtectHome=read-only

[Install]
WantedBy=multi-user.target
""")


def activate(d: dict, root: pathlib.Path, instance: str, bindir: pathlib.Path, dry: bool) -> int:
    print(f"\nACTIVATING {root}\n")
    nebula      = shutil.which("nebula")      or str(bindir / "nebula")
    nebula_cert = shutil.which("nebula-cert") or str(bindir / "nebula-cert")
    if not pathlib.Path(nebula).exists():
        print(f"   ⛔ nebula binary not found at {nebula}. Run the installer first.")
        return 1

    blockers = cert_gates(root, nebula_cert)
    if blockers:
        for b in blockers:
            print(f"   ⛔ {b}")
        return 1
    print("   ✓ certificate verifies against the CA")
    print("   ✓ certificate is bound to THIS machine's key (not merely valid)")
    print("   ✓ certificate is in date and addressed inside the overlay")

    rc, out = _run([nebula, "-test", "-config", str(root / "config.yml")])
    if rc != 0:
        print(f"   ⛔ config does not load: {out.splitlines()[-1] if out else rc}")
        return 1
    print("   ✓ config loads with the certificate in place")

    kind, path, body = render_service(d, root, nebula, instance)
    if kind == "systemd" and not d["systemd"]:
        print("\n   • no systemd on this machine, so there is no service to install.")
        print(f"     Run it yourself (as root, it needs to create a tun device):\n"
              f"       sudo {nebula} -config {root}/config.yml")
        return 0

    if dry:
        print(f"\n   (dry run) would write {kind} unit to {path}:\n")
        print("\n".join("       " + l for l in body.splitlines()))
        return 0

    # THE ONLY STEP THAT NEEDS ROOT. Nebula must create a tun device. Rather than invoke sudo
    # ourselves — which would mean prompting for a password from a script the user piped from the
    # internet — print the exact command and let them run it knowingly.
    if os.geteuid() != 0:
        print(f"\n   Everything checks out. The last step needs root, because nebula has to create")
        print(f"   a network device. Run:\n")
        print(f"       sudo {sys.executable} {pathlib.Path(__file__).resolve()} --activate \\")
        print(f"            --prefix {root.parent} --instance {instance}\n")
        return 0

    pathlib.Path(path).write_text(body)
    print(f"   ✓ {kind} unit written to {path}")
    if kind == "systemd":
        _run(["systemctl", "daemon-reload"])
        rc, out = _run(["systemctl", "enable", "--now", f"{instance}.service"], timeout=60)
    else:
        rc, out = _run(["launchctl", "load", "-w", path], timeout=60)
    if rc != 0:
        print(f"   ⛔ could not start the service: {out}")
        return 1
    print(f"   ✓ service enabled and started")

    # Prove it, do not assume it. A started service that never handshakes is the common failure.
    lighthouse = C["lighthouses"][0]
    rc, _ = _run(["ping", "-c", "2", "-W", "4", lighthouse], timeout=20)
    if rc == 0:
        print(f"   ✓ reached lighthouse {lighthouse} over the overlay — YOU ARE ON THE NETWORK")
    else:
        print(f"   ⚠ service is running but {lighthouse} did not answer yet.")
        print(f"     Handshakes can take a few seconds. Check:  journalctl -u {instance} -n 30")
    return 0


# ── binary acquisition ───────────────────────────────────────────────────────────────────────
# Fetching a binary and putting it on PATH is the most dangerous thing this tool does, so it is
# the part written most conservatively.
#
#   * The version is PINNED, never "latest" — a moving target is not reproducible and is a supply
#     chain a partner cannot audit.
#   * Checksums are PINNED IN THIS FILE, not fetched alongside the download. A checksum retrieved
#     over the same channel as the artifact catches corruption but NOT a compromised release;
#     hard-coding what we observed makes a substituted artifact fail here.
#   * ⚠ Honest limit: these were observed from the published SHASUM256.txt on 2026-08-16 and are
#     trusted-on-first-observation. They are not a signature and this is not attestation. Verify
#     independently before this ships to anyone outside the fleet.
def _load_constants() -> dict:
    """Network facts come from network_constants.json — the ONE source both installers read.

    Inlining any of these again reintroduces the drift this file exists to prevent (the
    blocklist once shipped with four of its five entries). No fallback on purpose: running
    with a guessed blocklist or a guessed lighthouse is worse than not running.
    """
    for d in _persona_dirs() + [HERE]:
        f = d / "network_constants.json"
        if f.is_file():
            return json.loads(f.read_text())
    raise SystemExit(
        "network_constants.json not found next to the installer. It carries the blocklist, "
        "lighthouses and pinned checksums; refusing to run without it.")


C = _load_constants()
REQUEST_SCHEMA = C["request_schema"]
NEBULA_MIN = tuple(C["nebula"]["min_version"])
NEBULA_PIN = C["nebula"]["pin"]
NEBULA_SHA256 = C["nebula"]["sha256"]


def _asset_for(d: dict) -> str | None:
    if d["os_class"] == "macos":
        return "nebula-darwin.zip"
    arch = {"aarch64": "arm64", "arm64": "arm64", "x86_64": "amd64"}.get(d["machine"])
    return f"nebula-linux-{arch}.tar.gz" if arch else None


def acquire_nebula(d: dict, bindir: pathlib.Path, expect: str | None = None) -> int:
    """Download the PINNED release, verify against the PINNED hash, extract to bindir."""
    asset = _asset_for(d)
    if not asset:
        print(f"   ⛔ no published nebula build for {d['machine']} — cannot acquire automatically")
        return 1
    want = expect or NEBULA_SHA256.get(asset)
    if not want:
        print(f"   ⛔ no pinned checksum for {asset} — refusing to install an unverified binary "
              f"(pass --expect-sha256 if you have verified it yourself)")
        return 1

    url = f"https://github.com/slackhq/nebula/releases/download/{NEBULA_PIN}/{asset}"
    print(f"   • fetching {NEBULA_PIN} {asset}")
    with tempfile.TemporaryDirectory() as td:
        blob = pathlib.Path(td) / asset
        try:
            with urllib.request.urlopen(url, timeout=60) as r, blob.open("wb") as f:
                shutil.copyfileobj(r, f)
        except (urllib.error.URLError, OSError) as e:
            print(f"   ⛔ download failed: {e}")
            return 1

        got = hashlib.sha256(blob.read_bytes()).hexdigest()
        if got != want:
            # Do not keep it, do not "try anyway". A mismatch is the check working.
            print(f"   ⛔ CHECKSUM MISMATCH — refusing to install\n"
                  f"        expected {want}\n        got      {got}")
            return 1
        print(f"   ✓ sha256 verified against the pinned value")

        try:
            if asset.endswith(".zip"):
                import zipfile
                with zipfile.ZipFile(blob) as z:
                    z.extractall(td)
            else:
                with tarfile.open(blob) as t:
                    t.extractall(td)          # release archives are flat: ./nebula, ./nebula-cert
        except Exception as e:
            print(f"   ⛔ extract failed: {e}")
            return 1

        bindir.mkdir(parents=True, exist_ok=True)
        for name in ("nebula", "nebula-cert"):
            src = pathlib.Path(td) / name
            if not src.is_file():
                print(f"   ⛔ {name} missing from the archive")
                return 1
            dst = bindir / name
            try:
                shutil.copy2(src, dst)
                os.chmod(dst, 0o755)
            except PermissionError:
                print(f"   ⛔ cannot write {dst} — rerun with --bindir ~/bin, or with sudo")
                return 1
        print(f"   ✓ nebula + nebula-cert installed to {bindir}")
    return 0


# ── execute ──────────────────────────────────────────────────────────────────────────────────
def _instance_root(d: dict, instance: str, prefix: str | None) -> pathlib.Path:
    """Where this instance lives. --prefix makes the whole install relocatable, which is what
    allows a real execute run to be exercised on a LIVE node without touching its live instance."""
    if prefix:
        return pathlib.Path(prefix).expanduser() / instance
    if d["os_class"] == "macos":
        return pathlib.Path(d["brew_prefix"] or "/opt/homebrew") / "etc" / instance
    return pathlib.Path("/etc") / instance


def render_config(d: dict, persona: dict, root: pathlib.Path) -> str:
    net = persona["network"]
    relay_lines = "\n".join(f'    - "{h}"' for h in C["relays"])
    lh_lines = "\n".join(f'    - "{h}"' for h in C["lighthouses"])
    blocklist = "\n".join("    - " + f for f in C["blocklist"])
    shm = "\n".join(f'  "{k}": {json.dumps(v)}' for k, v in C["static_host_map"].items())
    listen = "0" if not net.get("inbound_required") else "REPLACE_AT_SIGNING"
    dev = C["overlay"]["tun_dev"].get(d["os_class"] or "linux", "nebula1043") or '""'
    return f"""pki:
  ca: {root}/pki/ca.crt
  cert: {root}/pki/host.crt
  key: {root}/pki/host.key
  blocklist:
{blocklist}

static_host_map:
{shm}

lighthouse:
  am_lighthouse: false
  interval: 60
  hosts:
{lh_lines}

listen:
  host: 0.0.0.0
  port: {listen}

relay:
  am_relay: false
  use_relays: true
  relays:
{relay_lines}

punchy:
  punch: true
  respond: true

tun:
  disabled: false
  dev: {dev}
  mtu: {C["overlay"]["mtu"]}

logging:
  level: info
  format: text

firewall:
  conntrack:
    tcp_timeout: {C["conntrack"]["tcp_timeout"]}
    udp_timeout: {C["conntrack"]["udp_timeout"]}
    default_timeout: {C["conntrack"]["default_timeout"]}
  outbound:
    - {{ port: any, proto: any, host: any }}
  inbound:
    - {{ port: any, proto: icmp, host: any }}
"""


def do_execute(d: dict, persona: dict, root: pathlib.Path, force: bool,
               bindir: pathlib.Path, expect: str | None = None,
               force_acquire: bool = False) -> tuple[int, str | None]:
    """Idempotent and refusing. Returns (exit_code, host_pub)."""
    pki = root / "pki"
    key, pub, cfg = pki / "host.key", pki / "host.pub", root / "config.yml"

    # Look in OUR bindir before PATH: on a machine where a previous run already installed to
    # ~/.adna/bin (which is not on PATH), checking PATH alone re-downloaded ~10MB on every rerun.
    # Found by running the live installer twice and reading run 2's output — the state was
    # byte-identical, but "installed" should never appear twice for the same bytes.
    own = bindir / "nebula-cert"
    cert_bin = str(own) if own.is_file() and os.access(own, os.X_OK) else shutil.which("nebula-cert")
    if cert_bin == str(own) and d["nebula"] is None:
        # detect() only saw PATH; ask the binary we actually have, so the version gate still applies.
        rc, out = _run([str(bindir / "nebula"), "-version"])
        m = re.search(r"(\d+)\.(\d+)\.(\d+)", out)
        if m:
            d["nebula"] = tuple(int(x) for x in m.groups())
    need = force_acquire or (cert_bin is None) or (d["nebula"] is not None and d["nebula"] < NEBULA_MIN)
    if need:
        if acquire_nebula(d, bindir, expect):
            return 1, None
        cert_bin = str(bindir / "nebula-cert")
    else:
        print(f"   ✓ nebula-cert already present ({cert_bin}) — not re-downloading")

    try:
        pki.mkdir(parents=True, exist_ok=True)
    except PermissionError:
        print(f"   ⛔ cannot create {pki} — rerun with --prefix ~/somewhere, or with sudo")
        return 1, None

    # ⛔ NEVER regenerate over an existing private key. A new keypair silently invalidates every
    #    cert ever issued to this node, and the failure surfaces later as "your signature is wrong".
    if key.exists():
        print(f"   ✓ keypair already present at {key} — NOT regenerating (an existing key is never overwritten)")
    else:
        rc, out = _run([cert_bin, "keygen", "-out-key", str(key), "-out-pub", str(pub)])
        if rc != 0:
            print(f"   ⛔ keygen failed: {out}")
            return 1, None
        os.chmod(key, 0o600)
        print(f"   ✓ keypair generated at {key} (0600, never leaves this machine)")

    if cfg.exists() and not force:
        print(f"   ✓ config already present at {cfg} — left untouched (--force to overwrite)")
    else:
        cfg.write_text(render_config(d, persona, root))
        print(f"   ✓ config written to {cfg}")

    if shutil.which("nebula"):
        rc, out = _run(["nebula", "-test", "-config", str(cfg)])
        # Missing cert is the EXPECTED pre-signing state, not a failure.
        if rc == 0:
            print("   ✓ nebula -test: CONFIG OK")
        elif "host.crt" in out or "no such file" in out.lower():
            print("   ✓ nebula -test: config parses; only the unsigned cert is missing (expected)")
        else:
            print(f"   ⚠ nebula -test reported: {out.splitlines()[0][:100] if out else '?'}")

    host_pub = (_read(pub) or "").strip() or None
    print("   • service install + enrollment: NOT performed — this version stops here by design")
    return 0, host_pub


def load_persona(name: str) -> dict:
    tried = []
    for d in _persona_dirs():
        f = d / f"persona_{name}.json"
        tried.append(str(f))
        if f.is_file():
            return json.loads(_read(f) or "{}")
    sys.exit("no such persona: %s\n  looked in:\n    %s\n  (set ADNA_PERSONA_DIR to override)"
             % (name, "\n    ".join(tried)))


def self_test() -> int:
    """Every refusal must be PROVEN to fire — a control never seen to refuse is not a control."""
    persona = {"persona": "developer", "requires_ratification": [],
               "network": {"mesh_join": True, "role": "dial_out_client", "inbound_required": False},
               "cert_request": {"groups": [], "duration_hours": 8760}, "graphs": []}
    base = {"os": "linux", "machine": "x86_64", "hostname": "t", "is_wsl": False, "is_rpi": False,
            "os_class": "linux", "systemd": True, "ntp_synced": True, "nebula": (1, 11, 0),
            "brew_prefix": None, "public_ip": "203.0.113.5", "cgnat": False}
    assert not preflight(base, persona)[0], "baseline must have no blockers"

    cases = {
        "32-bit":      ({**base, "machine": "armv7l"}, persona),
        "old nebula":  ({**base, "nebula": (1, 9, 3)}, persona),
        "clock skew":  ({**base, "ntp_synced": False}, persona),
        "cgnat+inbound": ({**base, "cgnat": True},
                          {**persona, "network": {**persona["network"], "inbound_required": True}}),
        "unratified":  (base, {**persona, "requires_ratification": ["R1"]}),
    }
    bad = 0
    for label, (dd, pp) in cases.items():
        blockers, _ = preflight(dd, pp)
        if blockers:
            print(f"  ✓ refuses on {label}: {blockers[0][:76]}")
        else:
            print(f"  ✗ {label} DID NOT REFUSE — the check is decorative"); bad += 1
    print(f"\nself-test: {len(cases)-bad}/{len(cases)} refusals proven")

    # Packaging gate — added after the Pi caught a false green here (2026-08-16). The refusal cases
    # above use inline dicts, so they pass even when persona files cannot be found at all. A
    # self-test that greens on an unusable package is worse than no self-test.
    try:
        load_persona("developer")
        print("  ✓ packaging: persona files resolve from this layout")
    except SystemExit as e:
        print(f"  ✗ packaging: personas NOT resolvable — {str(e).splitlines()[0]}")
        bad += 1
    return 1 if bad else 0


def self_audit() -> int:
    touched = [p for p in _READS if any(p.endswith(s) or s in p for s in _KEY_SUFFIXES)]
    if touched:
        print("✗ private-key-shaped path(s) read this run:"); [print("   ", t) for t in touched]
        return 1
    print(f"✓ self-audit clean — {len(_READS)} path(s) read, none private-key-shaped")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="adna_install — node onboarding, no agent required.")
    ap.add_argument("--profile", default="developer", help="persona name (default: developer)")
    ap.add_argument("--execute", action="store_true", help="actually change this machine (default: dry-run)")
    ap.add_argument("--json", action="store_true", help="print the enrollment request as JSON")
    ap.add_argument("--online", action="store_true", help="opt-in: look up the public IP (CGNAT check)")
    ap.add_argument("--instance", default="nebula-1043",
                    help="instance dir name (default nebula-1043 — the LIVE one; use another for a test run)")
    ap.add_argument("--prefix", help="relocate the whole install under this dir (no sudo, touches no live instance)")
    ap.add_argument("--force", action="store_true", help="overwrite an existing config (never a key)")
    ap.add_argument("--bindir", help="where to install the nebula binaries (default /usr/local/bin)")
    ap.add_argument("--activate", action="store_true",
                    help="second step: after your signed certificate arrives, verify it and start the service")
    ap.add_argument("--no-workspace", action="store_true",
                    help="skip cloning the aDNA workspace (the network install is unaffected)")
    ap.add_argument("--force-acquire", action="store_true", help="download nebula even if a good one is present (test the supply-chain gate)")
    ap.add_argument("--expect-sha256", dest="expect", help="override the pinned checksum (you have verified it yourself)")
    ap.add_argument("--self-test", action="store_true")
    ap.add_argument("--self-audit", action="store_true")
    a = ap.parse_args()

    if a.self_test:
        return self_test()

    persona = load_persona(a.profile)
    d = detect()
    if a.online:
        public_ip(d)

    print(f"adna_install {VERSION} — persona '{persona['persona']}' ({persona.get('status','?')})")
    print(f"detected: {d['os_class']} · {d['machine']} · "
          f"{'WSL2 · ' if d['is_wsl'] else ''}{'RaspberryPi · ' if d['is_rpi'] else ''}"
          f"nebula={'.'.join(map(str,d['nebula'])) if d['nebula'] else 'absent'} · "
          f"systemd={'yes' if d['systemd'] else 'no'}\n")

    blockers, warns = preflight(d, persona)
    for w in warns:
        print(f"  ⚠ {w}\n")
    if blockers:
        print("⛔ STOPPING — this machine is not ready, and improvising around these is how nodes break:\n")
        for b in blockers:
            print(f"   • {b}\n")
        return 1

    if a.activate:
        return activate(d, _instance_root(d, a.instance, a.prefix), a.instance,
                        pathlib.Path(a.bindir).expanduser() if a.bindir else pathlib.Path("/usr/local/bin"),
                        dry=not a.execute)

    print("PLAN:" if not a.execute else "EXECUTING:")
    for s in plan(d, persona, a.instance, a.prefix):
        print(f"   {s}")

    host_pub = None
    if a.execute:
        root = _instance_root(d, a.instance, a.prefix)
        if a.instance == "nebula-1043" and not a.prefix:
            print(f"\n   ⚠ targeting the LIVE instance at {root}. Use --instance/--prefix for a test run.")
        bindir = pathlib.Path(a.bindir).expanduser() if a.bindir else pathlib.Path('/usr/local/bin')
        rc, host_pub = do_execute(d, persona, root, a.force, bindir, a.expect, a.force_acquire)
        if rc:
            return rc

    workspace = None
    if a.execute:
        workspace = setup_workspace(a.no_workspace)

    req = enrollment_request(d, persona, host_pub=host_pub)
    print(f"\nenrollment: auto_signable={req['cert_request']['auto_signable']}"
          f"  (ruling C — scoped certs only; anything privileged stays a human signing)")

    if not a.execute:
        print("\n(dry run — nothing was changed. re-run with --execute)")
        if a.json:
            print("\n" + json.dumps(req, indent=2))
    elif host_pub:
        # The whole point of a run is to produce the thing you send back, so it is ALWAYS
        # printed on a real install — it used to appear only under --json, which meant the
        # click-installer told people to send a block that was never shown to them.
        # Delimited with the `=====` ruler, so
        # "copy from here to here" is unambiguous for someone who does not read terminals.
        body = json.dumps(req, indent=2)
        out = root / "enrollment_request.json"
        try:
            out.write_text(body + "\n")
            saved = f"   Also saved to: {out}\n   (you can attach that file instead of copying)"
        except OSError as e:
            saved = f"   (could not save a copy: {e} — copy the text above instead)"

        print("\nNEXT: send this to whoever invited you. It contains your PUBLIC key only —")
        print("no private key, no password, nothing secret.\n")
        print("=" * 72)
        print("ENROLLMENT REQUEST — copy everything between these two lines")
        print("=" * 72)
        print(body)
        print("=" * 72)
        print("END ENROLLMENT REQUEST")
        print("=" * 72)
        print(saved)
    if workspace:
        print()
        print(f"   Your aDNA workspace is at {workspace}")
        print("   Open it however you like — a text editor, Obsidian, or an AI coding")
        print("   assistant if you use one. Nothing here requires any of them.")
    elif a.json:
        print("\n" + json.dumps(req, indent=2))
    if a.self_audit:
        print()
        return self_audit()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
